<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'config/db.php';

$stmtToday = $pdo->prepare("
    SELECT
        COUNT(*)      AS sessions_today,
        SUM(duration) AS focus_minutes_today
    FROM sessions
    WHERE user_id = :uid
      AND session_type = 'pomodoro'
      AND DATE(started_at) = CURDATE()
");
$stmtToday->execute([':uid' => $_SESSION['user_id']]);
$todayStats = $stmtToday->fetch();

$sessionsTodayDB  = (int)($todayStats['sessions_today']    ?? 0);
$focusMinsTodayDB = (int)($todayStats['focus_minutes_today'] ?? 0);

$stmtTasks = $pdo->prepare("
    SELECT id, title FROM tasks
    WHERE user_id = :uid AND status != 'done'
    ORDER BY created_at DESC
");
$stmtTasks->execute([':uid' => $_SESSION['user_id']]);
$userTasks = $stmtTasks->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="inner-page">

<?php include 'sidebar.php'; ?>

<div class="main-content">
<div class="timer-page">

    <!-- ── Page Header ── -->
    <div class="page-header">
        <div class="page-header-left">
            <div class="page-eyebrow"><i class="fas fa-bolt"></i> Focus Mode</div>
            <h1 class="page-title">POMODORO TIMER</h1>
            <p class="page-subtitle">Lock in. Stay focused. Get it done!</p>
        </div>
        <div class="session-counter">
            <div class="sc-flame"><i class="fas fa-fire"></i></div>
            <div class="sc-info">
                <span class="sc-val" id="sessionCount"><?php echo $sessionsTodayDB; ?></span>
                <span class="sc-label">sessions today</span>
            </div>
        </div>
    </div>

    <div class="timer-layout">

        <div class="timer-left">

            <div class="mode-tabs">
                <button class="mode-tab active" data-mode="pomodoro" onclick="switchMode('pomodoro')">
                    <i class="fas fa-brain"></i> Pomodoro Mode
                </button>
                <button class="mode-tab" data-mode="short" onclick="switchMode('short')">
                    <i class="fas fa-coffee"></i> Short Break
                </button>
                <button class="mode-tab" data-mode="long" onclick="switchMode('long')">
                    <i class="fas fa-couch"></i> Long Break
                </button>
            </div>

            <div class="timer-card" id="timerCard">

                <div class="blob blob-1"></div>
                <div class="blob blob-2"></div>

                <div class="timer-ring-wrap">
                    <svg class="timer-ring" viewBox="0 0 240 240" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="120" cy="120" r="104"
                            fill="none"
                            stroke="rgba(255,255,255,0.07)"
                            stroke-width="12"/>
                        <circle id="progressRing"
                            cx="120" cy="120" r="104"
                            fill="none"
                            stroke="url(#ringGrad)"
                            stroke-width="12"
                            stroke-linecap="round"
                            stroke-dasharray="653.45"
                            stroke-dashoffset="0"
                            transform="rotate(-90 120 120)"
                            style="transition: stroke-dashoffset 1s linear;"/>
                        <defs>
                            <linearGradient id="ringGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%"   stop-color="#ff6b6b"/>
                                <stop offset="100%" stop-color="#c0392b"/>
                            </linearGradient>
                        </defs>
                        <circle cx="120" cy="120" r="90"
                            fill="rgba(192,57,43,0.07)"/>
                    </svg>

                    <div class="timer-display">
                        <span class="timer-mode-label" id="modeLabel">FOCUS TIME</span>
                        <span class="timer-time"        id="timerDisplay">25:00</span>
                        <span class="timer-status"      id="timerStatus">Ready to start</span>
                    </div>
                </div>

                <div class="timer-controls">
                    <button class="ctrl-btn ctrl-btn--icon" onclick="resetTimer()" title="Reset">
                        <i class="fas fa-rotate-left"></i>
                    </button>
                    <button class="ctrl-btn ctrl-btn--main" id="startStopBtn" onclick="toggleTimer()">
                        <span class="ctrl-main-inner">
                            <i class="fas fa-play" id="startStopIcon"></i>
                            <span id="startStopLabel">Start</span>
                        </span>
                    </button>
                    <button class="ctrl-btn ctrl-btn--icon" onclick="skipSession()" title="Skip">
                        <i class="fas fa-forward-step"></i>
                    </button>
                </div>

                <div class="active-task-bar">
                    <div class="atb-icon"><i class="fas fa-bullseye"></i></div>
                    <select id="taskSelect" onchange="selectTask(this)">
                        <option value="">— No task selected —</option>
                        <?php foreach ($userTasks as $t): ?>
                        <option value="<?php echo $t['id']; ?>">
                            <?php echo htmlspecialchars($t['title']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <a href="tasks.php" class="atb-link" title="Manage tasks">
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </div>

            </div>

            <div class="timer-stats">
                <div class="stat-card stat-card--focus">
                    <div class="stat-bg-icon"><i class="fas fa-stopwatch"></i></div>
                    <div class="stat-icon-wrap"><i class="fas fa-stopwatch"></i></div>
                    <div class="stat-info">
                        <span class="stat-value" id="focusTime">0m</span>
                        <span class="stat-label">Focus today</span>
                    </div>
                </div>
                <div class="stat-card stat-card--sessions">
                    <div class="stat-bg-icon"><i class="fas fa-list-check"></i></div>
                    <div class="stat-icon-wrap"><i class="fas fa-list-check"></i></div>
                    <div class="stat-info">
                        <span class="stat-value" id="tasksCompleted">0</span>
                        <span class="stat-label">Tasks done</span>
                    </div>
                </div>
                <div class="stat-card stat-card--streak">
                    <div class="stat-bg-icon"><i class="fas fa-fire"></i></div>
                    <div class="stat-icon-wrap"><i class="fas fa-fire"></i></div>
                    <div class="stat-info">
                        <span class="stat-value" id="currentStreak">0</span>
                        <span class="stat-label">Streak</span>
                    </div>
                </div>
            </div>

        </div>

        <div class="timer-right">

            <div class="settings-panel">
                <div class="settings-panel-header">
                    <div class="settings-panel-icon"><i class="fas fa-sliders"></i></div>
                    <div>
                        <h3 class="settings-panel-title">Timer Settings</h3>
                        <p class="settings-panel-sub">Customize your sessions</p>
                    </div>
                </div>

                <div class="settings-body">

                    <div class="setting-group">
                        <p class="setting-group-label"><i class="fas fa-brain"></i> Durations</p>

                        <div class="setting-row">
                            <span class="setting-name">Focus</span>
                            <div class="setting-control">
                                <button class="setting-btn" onclick="adjustDuration('pomodoro', -5)">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <div class="setting-val-wrap">
                                    <span class="setting-val" id="pomodoroDuration">25</span>
                                    <span class="setting-unit">min</span>
                                </div>
                                <button class="setting-btn" onclick="adjustDuration('pomodoro', 5)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>

                        <div class="setting-row">
                            <span class="setting-name">Short Break</span>
                            <div class="setting-control">
                                <button class="setting-btn" onclick="adjustDuration('short', -1)">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <div class="setting-val-wrap">
                                    <span class="setting-val" id="shortDuration">5</span>
                                    <span class="setting-unit">min</span>
                                </div>
                                <button class="setting-btn" onclick="adjustDuration('short', 1)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>

                        <div class="setting-row">
                            <span class="setting-name">Long Break</span>
                            <div class="setting-control">
                                <button class="setting-btn" onclick="adjustDuration('long', -5)">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <div class="setting-val-wrap">
                                    <span class="setting-val" id="longDuration">15</span>
                                    <span class="setting-unit">min</span>
                                </div>
                                <button class="setting-btn" onclick="adjustDuration('long', 5)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="setting-divider"></div>

                    <div class="setting-group">
                        <p class="setting-group-label"><i class="fas fa-bell"></i> Preferences</p>

                        <div class="setting-row setting-row--toggle">
                            <div class="setting-toggle-info">
                                <span class="setting-name">Sound Alert</span>
                                <span class="setting-hint">Play sound when session ends</span>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="soundToggle" checked>
                                <span class="toggle-slider"></span>
                            </label>
                        </div>

                        <div class="setting-row setting-row--toggle">
                            <div class="setting-toggle-info">
                                <span class="setting-name">Auto-start Breaks</span>
                                <span class="setting-hint">Jump to break automatically</span>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="autoBreakToggle">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>

                    <div class="setting-divider"></div>

                    <div class="tip-card">
                        <div class="tip-card-header">
                            <i class="fas fa-lightbulb"></i> Study Tip
                        </div>
                        <p class="tip-card-body" id="studyTip">
                            After 4 Pomodoros, take a longer 15–30 minute break to fully recharge your brain.
                        </p>
                    </div>

                </div>
            </div>

        </div>

    </div>

</div>
</div>

<div class="modal-overlay" id="sessionModal">
    <div class="modal-card">
        <div class="modal-icon" id="modalIconWrap">
            <i class="fas fa-trophy" id="modalIcon"></i>
        </div>
        <h2 class="modal-title" id="modalTitle">Session Complete!</h2>
        <p class="modal-msg"    id="modalMsg">Great work! Take a short break.</p>
        <div class="modal-actions">
            <button class="modal-btn modal-btn--secondary" onclick="closeModal()">
                <i class="fas fa-xmark"></i> Dismiss
            </button>
            <button class="modal-btn modal-btn--primary" id="modalActionBtn" onclick="startBreak()">
                <i class="fas fa-coffee"></i> Start Break
            </button>
        </div>
    </div>
</div>

<style>
.timer-page {
    padding: 36px 40px 60px;
    max-width: 1100px;
    margin: 0 auto;
    width: 100%;
}

.page-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 32px;
    gap: 20px;
    flex-wrap: wrap;
}

.page-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #c0392b;
    background: rgba(192,57,43,0.08);
    padding: 4px 12px;
    border-radius: 99px;
    margin-bottom: 10px;
}

.page-title {
    font-family: 'Inter', sans-serif;
    font-size: 36px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -1.5px;
    line-height: 1;
    margin-bottom: 6px;
}

.page-subtitle {
    font-size: 15px;
    color: #999;
}

.session-counter {
    display: flex;
    align-items: center;
    gap: 14px;
    background: linear-gradient(135deg, #1a1a2e 0%, #2d2d44 100%);
    border-radius: 18px;
    padding: 14px 20px;
    box-shadow: 0 8px 24px rgba(26,26,46,0.2);
    min-width: 160px;
}

.sc-flame {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    background: rgba(192,57,43,0.25);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    color: #ff6b6b;
    flex-shrink: 0;
}

.sc-info { display: flex; flex-direction: column; gap: 2px; }

.sc-val {
    font-family: 'Syne', sans-serif;
    font-size: 28px;
    font-weight: 800;
    color: #fff;
    letter-spacing: -1px;
    line-height: 1;
}

.sc-label {
    font-size: 11px;
    color: rgba(255,255,255,0.45);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.timer-layout {
    display: grid;
    grid-template-columns: 1fr 340px;
    gap: 24px;
    align-items: start;
}

.timer-left {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 20px;
}

.mode-tabs {
    display: flex;
    background: #fff;
    border-radius: 16px;
    padding: 5px;
    gap: 4px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.07);
    border: 2px solid #f0f0f0;
    width: 100%;
    max-width: 500px;
}

.mode-tab {
    flex: 1;
    padding: 11px 16px;
    border-radius: 12px;
    border: none;
    background: none;
    font-size: 13px;
    font-weight: 700;
    color: #bbb;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    transition: all 0.25s ease;
    white-space: nowrap;
}

.mode-tab i { font-size: 12px; }
.mode-tab:hover { color: #555; background: #f7f7f7; }

.mode-tab.active {
    background: linear-gradient(135deg, #c0392b, #e74c3c);
    color: #fff;
    box-shadow: 0 6px 18px rgba(192,57,43,0.35);
}

.timer-card {
    background: linear-gradient(145deg, #1a1a1a 0%, #2a2020 100%);
    border-radius: 28px;
    padding: 44px 40px 36px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 30px;
    width: 100%;
    max-width: 500px;
    box-shadow:
        0 24px 80px rgba(0,0,0,0.3),
        0 0 0 1px rgba(255,255,255,0.04) inset;
    position: relative;
    overflow: hidden;
}

.blob {
    position: absolute;
    border-radius: 50%;
    pointer-events: none;
    filter: blur(40px);
}

.blob-1 {
    width: 220px;
    height: 220px;
    background: rgba(192,57,43,0.18);
    top: -80px;
    right: -60px;
}

.blob-2 {
    width: 160px;
    height: 160px;
    background: rgba(231,76,60,0.1);
    bottom: -60px;
    left: -40px;
}

.timer-ring-wrap {
    position: relative;
    width: 240px;
    height: 240px;
    flex-shrink: 0;
}

.timer-ring { width: 100%; height: 100%; }

.timer-display {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 6px;
}

.timer-mode-label {
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 3px;
    color: rgba(255,255,255,0.35);
    text-transform: uppercase;
}

.timer-time {
    font-family: 'Space Mono', monospace;
    font-size: 54px;
    font-weight: 700;
    color: #ffffff;
    letter-spacing: -3px;
    line-height: 1;
}

.timer-status {
    font-size: 11px;
    color: rgba(255,255,255,0.35);
    font-weight: 600;
    letter-spacing: 0.5px;
}

.timer-controls {
    display: flex;
    align-items: center;
    gap: 18px;
    z-index: 1;
}

.ctrl-btn {
    border: none;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
    transition: all 0.2s cubic-bezier(0.34,1.56,0.64,1);
    display: flex;
    align-items: center;
    justify-content: center;
}

.ctrl-btn--main {
    background: linear-gradient(135deg, #c0392b 0%, #e74c3c 100%);
    border-radius: 99px;
    padding: 3px;
    box-shadow: 0 8px 28px rgba(192,57,43,0.5), 0 0 0 1px rgba(255,255,255,0.1) inset;
    position: relative;
    overflow: hidden;
}

.ctrl-btn--main::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.15) 0%, transparent 50%);
    border-radius: inherit;
}

.ctrl-btn--main:hover {
    transform: translateY(-3px) scale(1.04);
    box-shadow: 0 14px 40px rgba(192,57,43,0.6);
}

.ctrl-btn--main:active { transform: scale(0.98); }

.ctrl-main-inner {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 15px 40px;
    font-size: 16px;
    font-weight: 800;
    color: #fff;
    font-family: 'Syne', sans-serif;
    letter-spacing: 0.5px;
}

.ctrl-btn--icon {
    background: rgba(255,255,255,0.07);
    color: rgba(255,255,255,0.55);
    width: 52px;
    height: 52px;
    border-radius: 50%;
    font-size: 16px;
    border: 1px solid rgba(255,255,255,0.08);
}

.ctrl-btn--icon:hover {
    background: rgba(255,255,255,0.13);
    color: #fff;
    transform: scale(1.1);
}

.active-task-bar {
    width: 100%;
    background: rgba(255,255,255,0.05);
    border-radius: 14px;
    padding: 13px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    border: 1px solid rgba(255,255,255,0.07);
    z-index: 1;
    backdrop-filter: blur(4px);
}

.atb-icon {
    width: 32px;
    height: 32px;
    background: rgba(192,57,43,0.3);
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ff6b6b;
    font-size: 13px;
    flex-shrink: 0;
}

.active-task-bar select {
    flex: 1;
    background: transparent;
    border: none;
    outline: none;
    font-size: 13px;
    color: rgba(255,255,255,0.6);
    font-family: 'Inter', sans-serif;
    cursor: pointer;
    min-width: 0;
    font-weight: 500;
}

.active-task-bar select option {
    background: #2a2a2a;
    color: #fff;
}

.atb-link {
    color: rgba(255,255,255,0.2);
    font-size: 13px;
    text-decoration: none;
    flex-shrink: 0;
    width: 28px;
    height: 28px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
}

.atb-link:hover {
    color: #ff6b6b;
    background: rgba(192,57,43,0.2);
}

.timer-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
    width: 100%;
    max-width: 500px;
}

.stat-card {
    border-radius: 18px;
    padding: 18px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    position: relative;
    overflow: hidden;
    transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.25s ease;
    animation: cardPop 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
}

.stat-card:hover { transform: translateY(-4px); }

.stat-card--focus {
    background: linear-gradient(135deg, #c0392b, #e74c3c);
    box-shadow: 0 8px 24px rgba(192,57,43,0.3);
}
.stat-card--focus:hover { box-shadow: 0 14px 36px rgba(192,57,43,0.45); }

.stat-card--sessions {
    background: linear-gradient(135deg, #1a6fa6, #2980b9);
    box-shadow: 0 8px 24px rgba(41,128,185,0.3);
}
.stat-card--sessions:hover { box-shadow: 0 14px 36px rgba(41,128,185,0.45); }

.stat-card--streak {
    background: linear-gradient(135deg, #d68910, #f39c12);
    box-shadow: 0 8px 24px rgba(214,137,16,0.3);
}
.stat-card--streak:hover { box-shadow: 0 14px 36px rgba(214,137,16,0.45); }

.stat-bg-icon {
    position: absolute;
    right: -8px;
    bottom: -8px;
    font-size: 56px;
    color: rgba(255,255,255,0.08);
    pointer-events: none;
}

.stat-icon-wrap {
    width: 36px;
    height: 36px;
    background: rgba(255,255,255,0.18);
    border-radius: 11px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    color: #fff;
    flex-shrink: 0;
    z-index: 1;
    backdrop-filter: blur(4px);
}

.stat-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
    z-index: 1;
}

.stat-value {
    font-family: 'Syne', sans-serif;
    font-size: 22px;
    font-weight: 800;
    color: #fff;
    line-height: 1;
    letter-spacing: -0.5px;
}

.stat-label {
    font-size: 10px;
    font-weight: 600;
    color: rgba(255,255,255,0.6);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.timer-right { position: sticky; top: 24px; }

.settings-panel {
    background: #fff;
    border-radius: 24px;
    border: 2px solid #f0f0f0;
    box-shadow: 0 4px 24px rgba(0,0,0,0.06);
    overflow: hidden;
    animation: fadeUp 0.5s ease 0.2s both;
}

.settings-panel-header {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 20px 22px;
    background: linear-gradient(135deg, #1a1a1a, #2d2d2d);
}

.settings-panel-icon {
    width: 38px;
    height: 38px;
    border-radius: 11px;
    background: rgba(192,57,43,0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    color: #ff6b6b;
    flex-shrink: 0;
}

.settings-panel-title {
    font-family: 'Syne', sans-serif;
    font-size: 16px;
    font-weight: 800;
    color: #fff;
    letter-spacing: -0.3px;
}

.settings-panel-sub {
    font-size: 12px;
    color: rgba(255,255,255,0.4);
    margin-top: 2px;
}

.settings-body { padding: 18px 22px; }

.setting-group { margin-bottom: 8px; }

.setting-group-label {
    font-size: 11px;
    font-weight: 700;
    color: #bbb;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.setting-group-label i { color: #c0392b; font-size: 10px; }

.setting-divider {
    height: 1px;
    background: #f0f0f0;
    margin: 16px 0;
}

.setting-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0;
    gap: 12px;
}

.setting-name {
    font-size: 13px;
    font-weight: 600;
    color: #333;
}

.setting-control {
    display: flex;
    align-items: center;
    gap: 8px;
}

.setting-val-wrap {
    display: flex;
    align-items: baseline;
    gap: 3px;
    min-width: 48px;
    justify-content: center;
    background: #f5f5f5;
    border-radius: 8px;
    padding: 4px 8px;
}

.setting-val {
    font-size: 16px;
    font-weight: 800;
    color: #1a1a1a;
    font-family: 'Space Mono', monospace;
    line-height: 1;
}

.setting-unit {
    font-size: 10px;
    color: #aaa;
    font-weight: 600;
}

.setting-btn {
    width: 30px;
    height: 30px;
    border-radius: 9px;
    border: 2px solid #f0f0f0;
    background: #fff;
    color: #888;
    font-size: 11px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s cubic-bezier(0.34,1.56,0.64,1);
}

.setting-btn:hover {
    background: linear-gradient(135deg, #c0392b, #e74c3c);
    border-color: transparent;
    color: #fff;
    transform: scale(1.1);
    box-shadow: 0 4px 12px rgba(192,57,43,0.35);
}

.setting-row--toggle { align-items: flex-start; }

.setting-toggle-info {
    display: flex;
    flex-direction: column;
    gap: 3px;
    flex: 1;
}

.setting-hint {
    font-size: 11px;
    color: #ccc;
    font-weight: 400;
}

.toggle-switch {
    position: relative;
    display: inline-block;
    width: 44px;
    height: 26px;
    cursor: pointer;
    flex-shrink: 0;
    margin-top: 2px;
}

.toggle-switch input { opacity: 0; width: 0; height: 0; }

.toggle-slider {
    position: absolute;
    inset: 0;
    background: #e5e5e5;
    border-radius: 99px;
    transition: background 0.25s ease;
}

.toggle-slider::before {
    content: '';
    position: absolute;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #fff;
    top: 3px;
    left: 3px;
    transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1);
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
}

.toggle-switch input:checked + .toggle-slider {
    background: linear-gradient(135deg, #c0392b, #e74c3c);
}

.toggle-switch input:checked + .toggle-slider::before {
    transform: translateX(18px);
}

.tip-card {
    background: linear-gradient(135deg, rgba(192,57,43,0.06), rgba(231,76,60,0.04));
    border: 1.5px solid rgba(192,57,43,0.12);
    border-radius: 14px;
    padding: 14px 16px;
    margin-top: 4px;
}

.tip-card-header {
    font-size: 12px;
    font-weight: 700;
    color: #c0392b;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.tip-card-body {
    font-size: 13px;
    color: #888;
    line-height: 1.6;
}


.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.55);
    backdrop-filter: blur(8px);
    z-index: 500;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-overlay.open {
    display: flex;
    animation: fadeIn 0.2s ease both;
}

.modal-card {
    background: #fff;
    border-radius: 28px;
    padding: 44px 36px;
    max-width: 380px;
    width: 100%;
    text-align: center;
    box-shadow: 0 40px 100px rgba(0,0,0,0.3);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    animation: modalPop 0.35s cubic-bezier(0.34,1.56,0.64,1) both;
}

.modal-icon {
    width: 72px;
    height: 72px;
    border-radius: 22px;
    background: linear-gradient(135deg, rgba(192,57,43,0.12), rgba(231,76,60,0.18));
    border: 2px solid rgba(192,57,43,0.12);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 4px;
}

.modal-icon i {
    font-size: 30px;
    color: #c0392b;
}

.modal-title {
    font-family: 'Syne', sans-serif;
    font-size: 24px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -0.5px;
}

.modal-msg {
    font-size: 14px;
    color: #999;
    line-height: 1.7;
}

.modal-actions {
    display: flex;
    gap: 10px;
    margin-top: 8px;
    width: 100%;
}

.modal-btn {
    flex: 1;
    padding: 14px;
    border-radius: 14px;
    border: none;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.2s ease;
}

.modal-btn--primary {
    background: linear-gradient(135deg, #c0392b, #e74c3c);
    color: #fff;
    box-shadow: 0 6px 20px rgba(192,57,43,0.4);
}

.modal-btn--primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 28px rgba(192,57,43,0.5);
}

.modal-btn--secondary {
    background: #f5f5f5;
    color: #888;
}

.modal-btn--secondary:hover { background: #eee; color: #555; }

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}

@keyframes fadeIn {
    from { opacity: 0; }
    to   { opacity: 1; }
}

@keyframes cardPop {
    from { opacity: 0; transform: translateY(16px) scale(0.96); }
    to   { opacity: 1; transform: translateY(0)    scale(1);    }
}

@keyframes modalPop {
    from { opacity: 0; transform: scale(0.88) translateY(20px); }
    to   { opacity: 1; transform: scale(1)    translateY(0);    }
}


@media (max-width: 900px) {
    .timer-layout { grid-template-columns: 1fr; }
    .timer-right  { position: static; }
    .settings-panel { max-width: 500px; margin: 0 auto; }
}

@media (max-width: 768px) {
    .timer-page   { padding: 20px 16px 40px; }
    .page-header  { flex-direction: column; gap: 12px; }
    .page-title   { font-size: 28px; }
    .timer-stats  { grid-template-columns: repeat(3,1fr); gap: 10px; }
    .stat-value   { font-size: 18px; }
    .timer-card   { padding: 32px 24px 28px; }
    .timer-time   { font-size: 46px; }
}

@media (max-width: 480px) {
    .timer-time   { font-size: 40px; }
    .timer-stats  { grid-template-columns: repeat(3,1fr); gap: 8px; }
    .stat-card    { padding: 14px 10px; gap: 8px; }
    .stat-value   { font-size: 16px; }
    .ctrl-main-inner { padding: 13px 28px; font-size: 14px; }
}
</style>

<script>
const TIPS = [
    "After 4 Pomodoros, take a longer 15–30 minute break to fully recharge your brain.",
    "Remove distractions before starting — silence your phone and close unused tabs.",
    "Write down your task clearly before the timer starts. Clarity = focus.",
    "If an idea pops up, jot it down quickly and get back to the task.",
    "Short breaks are for resting your brain, not scrolling social media!",
    "Consistency beats intensity. Even 4 Pomodoros a day adds up over time.",
];

document.getElementById('studyTip').textContent = TIPS[Math.floor(Math.random() * TIPS.length)];

const DURATIONS = { pomodoro: 25, short: 5, long: 15 };
let currentMode   = 'pomodoro';
let timeLeft      = DURATIONS.pomodoro * 60;
let totalTime     = DURATIONS.pomodoro * 60;
let timerInterval = null;
let isRunning     = false;
let sessionCount  = <?php echo $sessionsTodayDB; ?>;
let totalFocusSec = <?php echo $focusMinsTodayDB * 60; ?>;
let streak        = 0;

const CIRCUMFERENCE = 2 * Math.PI * 104;

const display   = document.getElementById('timerDisplay');
const statusEl  = document.getElementById('timerStatus');
const modeLbl   = document.getElementById('modeLabel');
const ring      = document.getElementById('progressRing');
const startIcon = document.getElementById('startStopIcon');
const startLbl  = document.getElementById('startStopLabel');
const sessionEl = document.getElementById('sessionCount');
const focusEl   = document.getElementById('focusTime');
const streakEl  = document.getElementById('currentStreak');

const modeLabels = {
    pomodoro: 'FOCUS TIME',
    short:    'SHORT BREAK',
    long:     'LONG BREAK'
};

function fmt(sec) {
    return `${Math.floor(sec/60).toString().padStart(2,'0')}:${(sec%60).toString().padStart(2,'0')}`;
}

function updateRing() {
    ring.style.strokeDashoffset = CIRCUMFERENCE * (1 - timeLeft / totalTime);
}

function switchMode(mode) {
    if (isRunning) resetTimer();
    currentMode = mode;
    timeLeft = totalTime = DURATIONS[mode] * 60;
    document.querySelectorAll('.mode-tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`[data-mode="${mode}"]`).classList.add('active');
    display.textContent = fmt(timeLeft);
    modeLbl.textContent = modeLabels[mode];
    statusEl.textContent = 'Ready to start';
    updateRing();
    updateDocTitle();
    document.getElementById('pomodoroDuration').textContent = DURATIONS.pomodoro;
    document.getElementById('shortDuration').textContent    = DURATIONS.short;
    document.getElementById('longDuration').textContent     = DURATIONS.long;
}

function toggleTimer() {
    isRunning ? pauseTimer() : startTimer();
}

function startTimer() {
    isRunning = true;
    startIcon.className    = 'fas fa-pause';
    startLbl.textContent   = 'Pause';
    statusEl.textContent   = currentMode === 'pomodoro' ? 'Focusing...' : 'On break...';
    timerInterval = setInterval(() => {
        timeLeft--;
        if (currentMode === 'pomodoro') totalFocusSec++;
        display.textContent = fmt(timeLeft);
        updateRing();
        updateDocTitle();
        updateStats();
        if (timeLeft <= 0) { clearInterval(timerInterval); onTimerEnd(); }
    }, 1000);
}

function pauseTimer() {
    isRunning = false;
    clearInterval(timerInterval);
    startIcon.className  = 'fas fa-play';
    startLbl.textContent = 'Resume';
    statusEl.textContent = 'Paused';
}

function resetTimer() {
    isRunning = false;
    clearInterval(timerInterval);
    timeLeft = totalTime = DURATIONS[currentMode] * 60;
    display.textContent  = fmt(timeLeft);
    startIcon.className  = 'fas fa-play';
    startLbl.textContent = 'Start';
    statusEl.textContent = 'Ready to start';
    updateRing();
    updateDocTitle();
}

function skipSession() {
    if (!confirm('Skip this session?')) return;
    clearInterval(timerInterval);
    onTimerEnd();
}

function onTimerEnd() {
    isRunning = false;
    startIcon.className  = 'fas fa-play';
    startLbl.textContent = 'Start';
    if (currentMode === 'pomodoro') {
        sessionCount++;
        streak++;
        sessionEl.textContent = sessionCount;
        streakEl.textContent  = streak;
        saveSession('pomodoro', DURATIONS.pomodoro);
        playSound();
        showModal('focus');
    } else {
        saveSession(currentMode === 'short' ? 'short_break' : 'long_break', DURATIONS[currentMode]);
        playSound();
        showModal('break');
    }
    updateStats();
    document.getElementById('studyTip').textContent = TIPS[Math.floor(Math.random() * TIPS.length)];
}

function updateStats() {
    const mins = Math.floor(totalFocusSec / 60);
    focusEl.textContent = mins > 0 ? `${mins}m` : '0m';
}

function updateDocTitle() {
    document.title = isRunning ? `${fmt(timeLeft)} – TimeSaver` : 'Timer – TimeSaver';
}

function playSound() {
    if (!document.getElementById('soundToggle').checked) return;
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        [0, 0.15, 0.3].forEach((delay, i) => {
            const osc  = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.value = i === 2 ? 880 : 660;
            osc.type = 'sine';
            gain.gain.setValueAtTime(0.3, ctx.currentTime + delay);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + 0.4);
            osc.start(ctx.currentTime + delay);
            osc.stop(ctx.currentTime  + delay + 0.5);
        });
    } catch(e) {}
}

function showModal(type) {
    const modal     = document.getElementById('sessionModal');
    const title     = document.getElementById('modalTitle');
    const msg       = document.getElementById('modalMsg');
    const icon      = document.getElementById('modalIcon').querySelector('i');
    const actionBtn = document.getElementById('modalActionBtn');
    if (type === 'focus') {
        title.textContent   = 'Session Complete! 🎉';
        msg.textContent     = `Awesome! You've done ${sessionCount} session${sessionCount > 1 ? 's' : ''} today. Take a well-deserved break!`;
        icon.className      = 'fas fa-trophy';
        actionBtn.innerHTML = '<i class="fas fa-coffee"></i> Start Break';
        actionBtn.onclick   = startBreak;
    } else {
        title.textContent   = 'Break Over! 💪';
        msg.textContent     = 'Time to lock back in. You got this!';
        icon.className      = 'fas fa-brain';
        actionBtn.innerHTML = '<i class="fas fa-play"></i> Start Focus';
        actionBtn.onclick   = startFocus;
    }
    modal.classList.add('open');
    if (type === 'focus' && document.getElementById('autoBreakToggle').checked) {
        setTimeout(() => { closeModal(); startBreak(); }, 1500);
    }
}

function closeModal() {
    document.getElementById('sessionModal').classList.remove('open');
}

function startBreak() {
    closeModal();
    switchMode(sessionCount % 4 === 0 ? 'long' : 'short');
    startTimer();
}

function startFocus() {
    closeModal();
    switchMode('pomodoro');
    startTimer();
}

let selectedTaskId = null;
function selectTask(sel) { selectedTaskId = sel.value || null; }

function saveSession(sessionType, durationMins) {
    fetch('save_session.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_type: sessionType, duration: durationMins, task_id: selectedTaskId })
    })
    .then(r => r.json())
    .then(data => { if (data.success) sessionEl.textContent = data.sessions_today; })
    .catch(err => console.error('Session save error:', err));
}

function adjustDuration(mode, delta) {
    const min = mode === 'pomodoro' ? 5 : 1;
    const max = mode === 'pomodoro' ? 60 : (mode === 'short' ? 15 : 30);
    DURATIONS[mode] = Math.min(max, Math.max(min, DURATIONS[mode] + delta));
    const ids = { pomodoro: 'pomodoroDuration', short: 'shortDuration', long: 'longDuration' };
    document.getElementById(ids[mode]).textContent = DURATIONS[mode];
    if (currentMode === mode) { resetTimer(); }
}

switchMode('pomodoro');
</script>

</body>
</html>