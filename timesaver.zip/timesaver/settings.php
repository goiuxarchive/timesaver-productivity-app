<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include 'config/db.php';
include 'csrf_helper.php';

$user_id = $_SESSION['user_id'];
$success = '';
$error   = '';

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute([':id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    if (!csrf_verify()) {
        $error = 'Invalid request. Please try again.';
    } else {
        $action = $_POST['action'];

        if ($action === 'update_profile') {
            $first_name = trim($_POST['first_name'] ?? '');
            $last_name  = trim($_POST['last_name']  ?? '');
            $email      = trim($_POST['email']       ?? '');

            if (empty($first_name) || empty($last_name) || empty($email)) {
                $error = 'All profile fields are required.';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = 'Please enter a valid email address.';
            } else {
                $chk = $pdo->prepare("SELECT id FROM users WHERE email = :email AND id != :id");
                $chk->execute([':email' => $email, ':id' => $user_id]);
                if ($chk->fetch()) {
                    $error = 'That email is already used by another account.';
                } else {
                    $upd = $pdo->prepare("UPDATE users SET first_name=:fn, last_name=:ln, email=:em WHERE id=:id");
                    $upd->execute([':fn' => $first_name, ':ln' => $last_name, ':em' => $email, ':id' => $user_id]);
                    $_SESSION['first_name'] = $first_name;
                    $_SESSION['last_name']  = $last_name;
                    $success = 'Profile updated successfully!';
                    $stmt->execute([':id' => $user_id]);
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                }
            }

        } elseif ($action === 'change_password') {
            $current = $_POST['current_password'] ?? '';
            $new     = $_POST['new_password']      ?? '';
            $confirm = $_POST['confirm_password']  ?? '';

            if (empty($current) || empty($new) || empty($confirm)) {
                $error = 'All password fields are required.';
            } elseif (strlen($new) < 8) {
                $error = 'New password must be at least 8 characters.';
            } elseif ($new !== $confirm) {
                $error = 'New password and confirmation do not match.';
            } elseif (!password_verify($current, $user['password'])) {
                $error = 'Your current password is incorrect.';
            } else {
                $hashed = password_hash($new, PASSWORD_DEFAULT);
                $upd = $pdo->prepare("UPDATE users SET password=:pw WHERE id=:id");
                $upd->execute([':pw' => $hashed, ':id' => $user_id]);
                $success = 'Password changed successfully!';
            }

        } elseif ($action === 'delete_account') {
            $confirm_pass = $_POST['delete_password'] ?? '';
            if (!password_verify($confirm_pass, $user['password'])) {
                $error = 'Incorrect password. Account not deleted.';
            } else {
                $pdo->prepare("DELETE FROM sessions WHERE user_id = :id")->execute([':id' => $user_id]);
                $pdo->prepare("DELETE FROM tasks    WHERE user_id = :id")->execute([':id' => $user_id]);
                $pdo->prepare("DELETE FROM users    WHERE id      = :id")->execute([':id' => $user_id]);
                session_destroy();
                header('Location: login.php?deleted=1');
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings – TimeSaver</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="inner-page">

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <div class="settings-page">

        <div class="page-header">
            <div class="page-header-left">
                <h1 class="page-title">Settings</h1>
                <p class="page-subtitle">Manage your account and preferences.</p>
            </div>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-circle-check"></i>
                <?php echo htmlspecialchars($success); ?>
                <button class="alert-close" onclick="this.parentElement.remove()"><i class="fas fa-xmark"></i></button>
            </div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-circle-exclamation"></i>
                <?php echo htmlspecialchars($error); ?>
                <button class="alert-close" onclick="this.parentElement.remove()"><i class="fas fa-xmark"></i></button>
            </div>
        <?php endif; ?>

        <div class="settings-layout">

            <aside class="settings-tabs">
                <button class="settings-tab active" onclick="switchTab('profile', this)">
                    <i class="fas fa-user"></i> Profile
                </button>
                <button class="settings-tab" onclick="switchTab('password', this)">
                    <i class="fas fa-lock"></i> Password
                </button>
                <button class="settings-tab" onclick="switchTab('timer', this)">
                    <i class="fas fa-stopwatch"></i> Timer Defaults
                </button>
                <button class="settings-tab" onclick="switchTab('danger', this)">
                    <i class="fas fa-triangle-exclamation"></i> Danger Zone
                </button>
            </aside>

            <div class="settings-panels">

                <div class="settings-panel active" id="panel-profile">
                    <div class="panel-header">
                        <div class="panel-icon panel-icon--red"><i class="fas fa-user"></i></div>
                        <div>
                            <h2 class="panel-title">Profile Information</h2>
                            <p class="panel-desc">Update your name and email address.</p>
                        </div>
                    </div>

                    <div class="avatar-row">
                        <div class="avatar-circle">
                            <span id="avatarInitials">
                                <?php echo strtoupper(substr($user['first_name'] ?? 'U', 0, 1) . substr($user['last_name'] ?? '', 0, 1)); ?>
                            </span>
                        </div>
                        <div class="avatar-info">
                            <p class="avatar-name"><?php echo htmlspecialchars(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')); ?></p>
                            <p class="avatar-email"><?php echo htmlspecialchars($user['email'] ?? ''); ?></p>
                            <span class="avatar-badge"><i class="fas fa-circle"></i> Active Student</span>
                        </div>
                    </div>

                    <form method="POST" action="" id="profileForm" novalidate>
                        <input type="hidden" name="action" value="update_profile">
                        <?= csrf_field() ?>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name"><i class="fas fa-user"></i> First Name</label>
                                <input type="text" id="first_name" name="first_name"
                                    value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>"
                                    placeholder="First name" required>
                                <span class="field-error" id="fnError"></span>
                            </div>
                            <div class="form-group">
                                <label for="last_name"><i class="fas fa-user"></i> Last Name</label>
                                <input type="text" id="last_name" name="last_name"
                                    value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>"
                                    placeholder="Last name" required>
                                <span class="field-error" id="lnError"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                            <input type="email" id="email" name="email"
                                value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>"
                                placeholder="your@email.com" required>
                            <span class="field-error" id="emailError"></span>
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-calendar"></i> Member Since</label>
                            <input type="text"
                                value="<?php echo isset($user['created_at']) ? date('F d, Y', strtotime($user['created_at'])) : 'N/A'; ?>"
                                disabled class="input-disabled">
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn-save" id="profileSubmit">
                                <i class="fas fa-floppy-disk"></i> Save Changes
                            </button>
                        </div>
                    </form>
                </div>

                <div class="settings-panel" id="panel-password">
                    <div class="panel-header">
                        <div class="panel-icon panel-icon--red"><i class="fas fa-lock"></i></div>
                        <div>
                            <h2 class="panel-title">Change Password</h2>
                            <p class="panel-desc">Use a strong password with at least 8 characters.</p>
                        </div>
                    </div>

                    <form method="POST" action="" id="passwordForm" novalidate>
                        <input type="hidden" name="action" value="change_password">
                        <?= csrf_field() ?>

                        <div class="form-group">
                            <label for="current_password"><i class="fas fa-lock"></i> Current Password</label>
                            <div class="input-wrap">
                                <input type="password" id="current_password" name="current_password"
                                    placeholder="Enter current password" required>
                                <button type="button" class="toggle-pw" onclick="togglePw('current_password', 'icon0')">
                                    <i class="fas fa-eye" id="icon0"></i>
                                </button>
                            </div>
                            <span class="field-error" id="curPwError"></span>
                        </div>

                        <div class="form-group">
                            <label for="new_password"><i class="fas fa-key"></i> New Password</label>
                            <div class="input-wrap">
                                <input type="password" id="new_password" name="new_password"
                                    placeholder="At least 8 characters" required>
                                <button type="button" class="toggle-pw" onclick="togglePw('new_password', 'icon1')">
                                    <i class="fas fa-eye" id="icon1"></i>
                                </button>
                            </div>
                            <div class="strength-bar-wrap" id="strengthWrap" style="display:none;">
                                <div class="strength-bar" id="strengthBar"></div>
                            </div>
                            <span class="strength-label" id="strengthLabel"></span>
                            <span class="field-error" id="newPwError"></span>
                        </div>

                        <div class="form-group">
                            <label for="confirm_password"><i class="fas fa-check-double"></i> Confirm New Password</label>
                            <div class="input-wrap">
                                <input type="password" id="confirm_password" name="confirm_password"
                                    placeholder="Repeat new password" required>
                                <button type="button" class="toggle-pw" onclick="togglePw('confirm_password', 'icon2')">
                                    <i class="fas fa-eye" id="icon2"></i>
                                </button>
                            </div>
                            <span class="field-error" id="confirmPwError"></span>
                        </div>

                        <div class="password-tips">
                            <p class="tips-title"><i class="fas fa-shield-halved"></i> Password Tips</p>
                            <ul>
                                <li id="tip-len"><i class="fas fa-circle"></i> At least 8 characters</li>
                                <li id="tip-num"><i class="fas fa-circle"></i> Contains a number</li>
                                <li id="tip-sym"><i class="fas fa-circle"></i> Contains a special character</li>
                            </ul>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn-save">
                                <i class="fas fa-floppy-disk"></i> Update Password
                            </button>
                        </div>
                    </form>
                </div>

                <div class="settings-panel" id="panel-timer">
                    <div class="panel-header">
                        <div class="panel-icon panel-icon--red"><i class="fas fa-stopwatch"></i></div>
                        <div>
                            <h2 class="panel-title">Timer Defaults</h2>
                            <p class="panel-desc">Customize your Pomodoro session durations. Saved in your browser.</p>
                        </div>
                    </div>

                    <div class="timer-presets">
                        <div class="preset-card preset-active" onclick="applyPreset(25,5,15, this)">
                            <i class="fas fa-brain"></i>
                            <strong>Classic</strong>
                            <span>25 / 5 / 15 min</span>
                        </div>
                        <div class="preset-card" onclick="applyPreset(50,10,30, this)">
                            <i class="fas fa-fire"></i>
                            <strong>Deep Work</strong>
                            <span>50 / 10 / 30 min</span>
                        </div>
                        <div class="preset-card" onclick="applyPreset(15,3,10, this)">
                            <i class="fas fa-bolt"></i>
                            <strong>Sprint</strong>
                            <span>15 / 3 / 10 min</span>
                        </div>
                    </div>

                    <div class="timer-fields">
                        <div class="form-group">
                            <label for="t_pomodoro">
                                <i class="fas fa-brain"></i> Pomodoro Duration
                                <span class="unit-label">minutes</span>
                            </label>
                            <input type="number" id="t_pomodoro" name="t_pomodoro" min="1" max="120" value="25">
                        </div>
                        <div class="form-group">
                            <label for="t_short">
                                <i class="fas fa-coffee"></i> Short Break
                                <span class="unit-label">minutes</span>
                            </label>
                            <input type="number" id="t_short" name="t_short" min="1" max="60" value="5">
                        </div>
                        <div class="form-group">
                            <label for="t_long">
                                <i class="fas fa-couch"></i> Long Break
                                <span class="unit-label">minutes</span>
                            </label>
                            <input type="number" id="t_long" name="t_long" min="1" max="120" value="15">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="toggle-label">
                            <i class="fas fa-bell"></i> Sound Notifications
                            <div class="toggle-switch" onclick="toggleSwitch(this)" id="soundToggle">
                                <div class="toggle-thumb"></div>
                            </div>
                        </label>
                        <p class="field-hint">Play a sound when a session or break ends.</p>
                    </div>

                    <div class="form-group">
                        <label class="toggle-label">
                            <i class="fas fa-rotate"></i> Auto-start Next Session
                            <div class="toggle-switch" onclick="toggleSwitch(this)" id="autoToggle">
                                <div class="toggle-thumb"></div>
                            </div>
                        </label>
                        <p class="field-hint">Automatically begin the next Pomodoro after a break.</p>
                    </div>

                    <div class="form-actions">
                        <button type="button" class="btn-save" onclick="saveTimerSettings()">
                            <i class="fas fa-floppy-disk"></i> Save Timer Settings
                        </button>
                        <button type="button" class="btn-outline" onclick="resetTimerSettings()">
                            <i class="fas fa-rotate-left"></i> Reset Defaults
                        </button>
                    </div>
                </div>

                <div class="settings-panel" id="panel-danger">
                    <div class="panel-header">
                        <div class="panel-icon panel-icon--danger"><i class="fas fa-triangle-exclamation"></i></div>
                        <div>
                            <h2 class="panel-title">Danger Zone</h2>
                            <p class="panel-desc">These actions are permanent and cannot be undone.</p>
                        </div>
                    </div>

                    <div class="danger-card">
                        <div class="danger-card-info">
                            <h3><i class="fas fa-trash-can"></i> Delete Account</h3>
                            <p>Permanently delete your account and all data — tasks, sessions, and progress. This cannot be reversed.</p>
                        </div>
                        <button class="btn-danger" onclick="openDeleteModal()">
                            Delete My Account
                        </button>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="deleteModal">
    <div class="modal-card modal-card--sm">
        <div class="modal-icon-danger"><i class="fas fa-triangle-exclamation"></i></div>
        <h3 class="modal-title">Delete Account?</h3>
        <p class="modal-desc">All your tasks, sessions, and progress will be permanently removed. Enter your password to confirm.</p>
        <form method="POST" action="">
            <input type="hidden" name="action" value="delete_account">
            <?= csrf_field() ?>
            <div class="form-group" style="margin-bottom:16px;">
                <div class="input-wrap">
                    <input type="password" name="delete_password" id="delete_password"
                        placeholder="Enter your password" required>
                    <button type="button" class="toggle-pw" onclick="togglePw('delete_password','icon_del')">
                        <i class="fas fa-eye" id="icon_del"></i>
                    </button>
                </div>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn-outline" onclick="closeDeleteModal()">Cancel</button>
                <button type="submit" class="btn-danger" style="flex:1;">
                    <i class="fas fa-trash-can"></i> Yes, Delete
                </button>
            </div>
        </form>
    </div>
</div>

<div class="toast" id="toast"></div>

<style>
.settings-page {
    padding: 32px 36px 60px;
    max-width: 900px;
    width: 100%;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 28px;
}

.page-title {
    font-size: 28px;
    font-weight: 900;
    color: #1a1a1a;
    margin-bottom: 4px;
}

.page-subtitle {
    font-size: 14px;
    color: #888;
}

.alert {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 13px 16px;
    border-radius: 12px;
    font-size: 14px;
    font-weight: 500;
    margin-bottom: 24px;
}
.alert-success { background: #eafaf1; color: #1e8449; border: 1px solid #a9dfbf; }
.alert-error   { background: #fdecea; color: #800517; border: 1px solid #f5c6c2; }
.alert-close   { background: none; border: none; cursor: pointer; color: inherit; font-size: 14px; margin-left: auto; }

.settings-layout {
    display: grid;
    grid-template-columns: 200px 1fr;
    gap: 24px;
    align-items: start;
}

.settings-tabs {
    background: #fff;
    border-radius: 14px;
    border: 1px solid #eee;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    overflow: hidden;
    position: sticky;
    top: 24px;
    display: flex;
    flex-direction: column;
}

.settings-tab {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 18px;
    background: none;
    border: none;
    border-left: 3px solid transparent;
    font-size: 14px;
    font-weight: 600;
    color: #888;
    cursor: pointer;
    text-align: left;
    transition: all 0.2s ease;
    font-family: 'Inter', sans-serif;
}

.settings-tab:hover {
    background: #fafafa;
    color: #1a1a1a;
}

.settings-tab.active {
    background: #fef5f4;
    color: #800517;
    border-left-color: #800517;
}

.settings-tab i {
    width: 16px;
    text-align: center;
    font-size: 13px;
}

.settings-panel {
    display: none;
    background: #fff;
    border-radius: 14px;
    border: 1px solid #eee;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    padding: 32px;
    animation: fadePanel 0.2s ease;
    max-width: 620px;       
    width: 100%;
}

.settings-panel.active { display: block; }

@keyframes fadePanel {
    from { opacity: 0; transform: translateY(8px); }
    to   { opacity: 1; transform: translateY(0); }
}

.panel-header {
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 28px;
    padding-bottom: 20px;
    border-bottom: 1px solid #f0f0f0;
}

.panel-icon {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    flex-shrink: 0;
}

.panel-icon--red    { background: rgba(192,57,43,0.1); color: #800517; }
.panel-icon--danger { background: rgba(192,57,43,0.12); color: #800517; }

.panel-title {
    font-size: 18px;
    font-weight: 800;
    color: #1a1a1a;
    margin-bottom: 3px;
}

.panel-desc {
    font-size: 13px;
    color: #999;
}

.avatar-row {
    display: flex;
    align-items: center;
    gap: 18px;
    background: #fafafa;
    border-radius: 12px;
    padding: 18px 20px;
    margin-bottom: 24px;
    border: 1px solid #f0f0f0;
}

.avatar-circle {
    width: 56px;
    height: 56px;
    border-radius: 14px;
    background: #800517;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    font-weight: 900;
    color: #fff;
    flex-shrink: 0;
    font-family: 'Space Mono', monospace;
}

.avatar-name  { font-size: 15px; font-weight: 700; color: #1a1a1a; margin-bottom: 2px; }
.avatar-email { font-size: 13px; color: #888; margin-bottom: 6px; }
.avatar-badge {
    font-size: 11px;
    color: #276221;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 5px;
}
.avatar-badge i { font-size: 7px; }

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: flex;
    align-items: center;
    gap: 7px;
    font-size: 13px;
    font-weight: 600;
    color: #444;
    margin-bottom: 8px;
}

.form-group label i {
    color: #800517;
    font-size: 12px;
    width: 14px;
}

.form-group input[type="text"],
.form-group input[type="email"],
.form-group input[type="password"],
.form-group input[type="number"] {
    width: 75%;
    padding: 11px 14px;
    border: 1.5px solid #e8e8e8;
    border-radius: 10px;
    font-size: 14px;
    color: #1a1a1a;
    font-family: 'Inter', sans-serif;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
    background: #fff;
    outline: none;
}

.form-group input:focus {
    border-color: #800517;
    box-shadow: 0 0 0 3px rgba(192,57,43,0.08);
}

.input-disabled {
    background: #f5f5f5 !important;
    color: #aaa !important;
    cursor: not-allowed;
}

.input-wrap {
    position: relative;
}

.input-wrap input {
    padding-right: 44px !important;
}

.toggle-pw {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    color: #bbb;
    font-size: 14px;
    padding: 4px;
    transition: color 0.2s;
}

.toggle-pw:hover { color: #800517; }

.field-error {
    display: block;
    color: #800517;
    font-size: 12px;
    margin-top: 5px;
    min-height: 14px;
}

.field-hint {
    font-size: 12px;
    color: #bbb;
    margin-top: 5px;
}

.unit-label {
    margin-left: auto;
    font-size: 11px;
    font-weight: 500;
    color: #bbb;
    background: #f5f5f5;
    padding: 2px 8px;
    border-radius: 99px;
}

.strength-bar-wrap {
    height: 4px;
    background: #eee;
    border-radius: 99px;
    margin-top: 8px;
    overflow: hidden;
}

.strength-bar {
    height: 100%;
    border-radius: 99px;
    width: 0%;
    transition: width 0.3s ease, background 0.3s ease;
}

.strength-label {
    display: block;
    font-size: 12px;
    font-weight: 600;
    margin-top: 5px;
}

.password-tips {
    background: #fafafa;
    border-radius: 10px;
    padding: 14px 16px;
    margin-bottom: 20px;
    border: 1px solid #f0f0f0;
}

.tips-title {
    font-size: 12px;
    font-weight: 700;
    color: #555;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 7px;
}

.tips-title i { color: #800517; }

.password-tips ul {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.password-tips li {
    font-size: 12px;
    color: #bbb;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: color 0.2s;
}

.password-tips li i { font-size: 7px; }
.password-tips li.tip-ok { color: #276221; }
.password-tips li.tip-ok i { color: #276221; }

.timer-presets {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    margin-bottom: 24px;
}

.preset-card {
    background: #fafafa;
    border: 2px solid #eee;
    border-radius: 12px;
    padding: 16px 12px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
}

.preset-card:hover {
    border-color: #800517;
    background: #fef5f4;
}

.preset-card.preset-active {
    border-color: #800517;
    background: rgba(192,57,43,0.06);
}

.preset-card i {
    font-size: 20px;
    color: #800517;
}

.preset-card strong {
    font-size: 13px;
    font-weight: 700;
    color: #1a1a1a;
}

.preset-card span {
    font-size: 11px;
    color: #999;
}

.timer-fields {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
}

.toggle-label {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between;
    cursor: default !important;
}

.toggle-switch {
    width: 42px;
    height: 24px;
    background: #ddd;
    border-radius: 99px;
    position: relative;
    cursor: pointer;
    transition: background 0.25s ease;
    flex-shrink: 0;
}

.toggle-switch.on { background: #800517; }

.toggle-thumb {
    width: 18px;
    height: 18px;
    background: #fff;
    border-radius: 50%;
    position: absolute;
    top: 3px;
    left: 3px;
    transition: left 0.25s ease;
    box-shadow: 0 1px 4px rgba(0,0,0,0.2);
}

.toggle-switch.on .toggle-thumb { left: 21px; }

.danger-card {
    background: #fef5f4;
    border: 1.5px solid #f5c6c2;
    border-radius: 12px;
    padding: 20px 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.danger-card h3 {
    font-size: 15px;
    font-weight: 700;
    color: #800517;
    margin-bottom: 6px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.danger-card p {
    font-size: 13px;
    color: #888;
    line-height: 1.6;
    max-width: 500px;
}

.form-actions {
    display: flex;
    gap: 12px;
    margin-top: 8px;
}

.btn-save {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 24px;
    background: #800517;
    color: #fff;
    border: none;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
    transition: background 0.2s ease, transform 0.15s ease, box-shadow 0.2s ease;
    box-shadow: 0 4px 14px rgba(192,57,43,0.3);
}

.btn-save:hover {
    background: #a93226;
    transform: translateY(-1px);
    box-shadow: 0 6px 20px rgba(192,57,43,0.4);
}

.btn-outline {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 20px;
    background: #fff;
    color: #555;
    border: 1.5px solid #ddd;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
    transition: all 0.2s ease;
}

.btn-outline:hover {
    border-color: #bbb;
    background: #fafafa;
}

.btn-danger {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 11px 22px;
    background: #800517;
    color: #fff;
    border: none;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
    transition: background 0.2s ease;
    white-space: nowrap;
}

.btn-danger:hover { background: #a93226; }

.modal-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(3px);
    z-index: 500;
    align-items: center;
    justify-content: center;
}

.modal-overlay.open { display: flex; }

.modal-card {
    background: #fff;
    border-radius: 18px;
    padding: 32px 28px;
    max-width: 400px;
    width: 90%;
    text-align: center;
    box-shadow: 0 20px 60px rgba(0,0,0,0.2);
    animation: popIn 0.25s cubic-bezier(0.34,1.56,0.64,1);
}

@keyframes popIn {
    from { transform: scale(0.85); opacity: 0; }
    to   { transform: scale(1);    opacity: 1; }
}

.modal-icon-danger {
    width: 60px;
    height: 60px;
    background: rgba(192,57,43,0.1);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    color: #800517;
    margin: 0 auto 16px;
}

.modal-title {
    font-size: 20px;
    font-weight: 800;
    color: #1a1a1a;
    margin-bottom: 8px;
}

.modal-desc {
    font-size: 13px;
    color: #888;
    line-height: 1.6;
    margin-bottom: 20px;
}

.modal-actions {
    display: flex;
    gap: 10px;
    margin-top: 4px;
}

.toast {
    position: fixed;
    bottom: 28px;
    right: 28px;
    background: #1a1a1a;
    color: #fff;
    font-size: 14px;
    font-weight: 600;
    padding: 13px 20px;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.2);
    opacity: 0;
    transform: translateY(12px);
    transition: opacity 0.3s ease, transform 0.3s ease;
    pointer-events: none;
    z-index: 999;
    display: flex;
    align-items: center;
    gap: 10px;
}

.toast.show {
    opacity: 1;
    transform: translateY(0);
}

@media (max-width: 768px) {
    .settings-page   { padding: 16px 14px 40px; }
    .settings-layout { grid-template-columns: 1fr; gap: 14px; }
    .settings-tabs   { flex-direction: row; flex-wrap: wrap; position: static; border-radius: 12px; }
    .settings-tab    { flex: 1; min-width: 70px; text-align: center; justify-content: center;
                       border-left: none; border-bottom: 3px solid transparent; padding: 10px 8px; font-size: 12px; }
    .settings-tab i  { display: none; }
    .settings-tab.active { border-bottom-color: #800517; border-left-color: transparent; }
    .settings-panel  { padding: 20px 16px; }
    .form-row        { grid-template-columns: 1fr; }
    .timer-presets   { grid-template-columns: 1fr; }
    .timer-fields    { grid-template-columns: 1fr; }
    .danger-card     { flex-direction: column; align-items: flex-start; gap: 14px; }
    .danger-card .btn-danger { width: 100%; justify-content: center; }
    .avatar-row      { flex-direction: column; text-align: center; align-items: center; }
    .panel-header    { flex-direction: column; text-align: center; gap: 10px; }
    .form-actions    { flex-direction: column; }
    .btn-save, .btn-outline { width: 100%; justify-content: center; }
    .modal-card      { width: calc(100vw - 24px); padding: 24px 16px; }
    .modal-actions   { flex-direction: column; }
    .modal-actions button { width: 100%; justify-content: center; }
}

@media (max-width: 480px) {
    .settings-tab  { font-size: 11px; padding: 9px 6px; }
    .panel-title   { font-size: 16px; }
    .preset-card   { padding: 12px 10px; }
    .timer-fields input[type="number"] { font-size: 16px; }
}
</style>

<script>
function switchTab(tab, el) {
    document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.settings-panel').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('panel-' + tab).classList.add('active');
}

function togglePw(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon  = document.getElementById(iconId);
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    icon.className = isHidden ? 'fas fa-eye-slash' : 'fas fa-eye';
}

document.getElementById('new_password').addEventListener('input', function () {
    const val  = this.value;
    const wrap  = document.getElementById('strengthWrap');
    const bar   = document.getElementById('strengthBar');
    const label = document.getElementById('strengthLabel');
    const tipLen = document.getElementById('tip-len');
    const tipNum = document.getElementById('tip-num');
    const tipSym = document.getElementById('tip-sym');

    if (!val) {
        wrap.style.display  = 'none';
        label.textContent   = '';
        label.style.color   = '';
        [tipLen, tipNum, tipSym].forEach(t => t.classList.remove('tip-ok'));
        return;
    }

    wrap.style.display = 'block';
    const hasLen = val.length >= 8;
    const hasNum = /\d/.test(val);
    const hasSym = /[^a-zA-Z0-9]/.test(val);

    hasLen ? tipLen.classList.add('tip-ok') : tipLen.classList.remove('tip-ok');
    hasNum ? tipNum.classList.add('tip-ok') : tipNum.classList.remove('tip-ok');
    hasSym ? tipSym.classList.add('tip-ok') : tipSym.classList.remove('tip-ok');

    const score = [hasLen, hasNum, hasSym].filter(Boolean).length;
    const configs = [
        { w: '33%', bg: '#e74c3c', text: 'Weak',   color: '#e74c3c' },
        { w: '66%', bg: '#e67e22', text: 'Fair',   color: '#e67e22' },
        { w: '100%',bg: '#276221', text: 'Strong', color: '#276221' },
    ];
    const cfg = configs[score - 1] || configs[0];
    bar.style.width      = cfg.w;
    bar.style.background = cfg.bg;
    label.textContent    = cfg.text;
    label.style.color    = cfg.color;
});

document.getElementById('profileForm').addEventListener('submit', function (e) {
    let valid = true;
    const fn = document.getElementById('first_name');
    const ln = document.getElementById('last_name');
    const em = document.getElementById('email');

    ['fnError','lnError','emailError'].forEach(id => document.getElementById(id).textContent = '');
    [fn, ln, em].forEach(el => el.style.borderColor = '');

    if (!fn.value.trim()) { document.getElementById('fnError').textContent = 'First name is required.'; fn.style.borderColor = '#800517'; valid = false; }
    if (!ln.value.trim()) { document.getElementById('lnError').textContent = 'Last name is required.';  ln.style.borderColor = '#800517'; valid = false; }
    if (!em.value.trim()) {
        document.getElementById('emailError').textContent = 'Email is required.'; em.style.borderColor = '#800517'; valid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em.value.trim())) {
        document.getElementById('emailError').textContent = 'Enter a valid email.'; em.style.borderColor = '#800517'; valid = false;
    }

    if (!valid) e.preventDefault();

    const initials = (fn.value.trim()[0] || '') + (ln.value.trim()[0] || '');
    document.getElementById('avatarInitials').textContent = initials.toUpperCase();
});

document.getElementById('passwordForm').addEventListener('submit', function (e) {
    let valid = true;
    const cur  = document.getElementById('current_password');
    const nw   = document.getElementById('new_password');
    const conf = document.getElementById('confirm_password');

    ['curPwError','newPwError','confirmPwError'].forEach(id => document.getElementById(id).textContent = '');
    [cur, nw, conf].forEach(el => el.style.borderColor = '');

    if (!cur.value)  { document.getElementById('curPwError').textContent  = 'Current password is required.'; cur.style.borderColor  = '#800517'; valid = false; }
    if (!nw.value)   { document.getElementById('newPwError').textContent  = 'New password is required.';     nw.style.borderColor   = '#800517'; valid = false; }
    else if (nw.value.length < 8) { document.getElementById('newPwError').textContent = 'At least 8 characters.'; nw.style.borderColor = '#800517'; valid = false; }
    if (nw.value && conf.value !== nw.value) { document.getElementById('confirmPwError').textContent = 'Passwords do not match.'; conf.style.borderColor = '#800517'; valid = false; }

    if (!valid) e.preventDefault();
});

function toggleSwitch(el) {
    el.classList.toggle('on');
    saveTimerToStorage();
}

function applyPreset(pom, sh, lng, el) {
    document.querySelectorAll('.preset-card').forEach(c => c.classList.remove('preset-active'));
    el.classList.add('preset-active');
    document.getElementById('t_pomodoro').value = pom;
    document.getElementById('t_short').value    = sh;
    document.getElementById('t_long').value     = lng;
}

function saveTimerSettings() {
    const pom   = parseInt(document.getElementById('t_pomodoro').value) || 25;
    const sh    = parseInt(document.getElementById('t_short').value)    || 5;
    const lng   = parseInt(document.getElementById('t_long').value)     || 15;
    const sound = document.getElementById('soundToggle').classList.contains('on');
    const auto  = document.getElementById('autoToggle').classList.contains('on');

    if (pom < 1 || sh < 1 || lng < 1) { showToast('⚠️ Durations must be at least 1 minute.'); return; }

    localStorage.setItem('ts_pomodoro', pom);
    localStorage.setItem('ts_short',    sh);
    localStorage.setItem('ts_long',     lng);
    localStorage.setItem('ts_sound',    sound);
    localStorage.setItem('ts_auto',     auto);
    showToast('✅ Timer settings saved!');
}

function saveTimerToStorage() {
    const sound = document.getElementById('soundToggle').classList.contains('on');
    const auto  = document.getElementById('autoToggle').classList.contains('on');
    localStorage.setItem('ts_sound', sound);
    localStorage.setItem('ts_auto',  auto);
}

function resetTimerSettings() {
    localStorage.removeItem('ts_pomodoro');
    localStorage.removeItem('ts_short');
    localStorage.removeItem('ts_long');
    localStorage.removeItem('ts_sound');
    localStorage.removeItem('ts_auto');
    document.getElementById('t_pomodoro').value = 25;
    document.getElementById('t_short').value    = 5;
    document.getElementById('t_long').value     = 15;
    document.getElementById('soundToggle').classList.remove('on');
    document.getElementById('autoToggle').classList.remove('on');
    document.querySelectorAll('.preset-card').forEach((c,i) => c.classList.toggle('preset-active', i === 0));
    showToast('🔄 Timer reset to defaults.');
}

function loadTimerSettings() {
    const pom   = localStorage.getItem('ts_pomodoro');
    const sh    = localStorage.getItem('ts_short');
    const lng   = localStorage.getItem('ts_long');
    const sound = localStorage.getItem('ts_sound') === 'true';
    const auto  = localStorage.getItem('ts_auto')  === 'true';

    if (pom) document.getElementById('t_pomodoro').value = pom;
    if (sh)  document.getElementById('t_short').value    = sh;
    if (lng) document.getElementById('t_long').value     = lng;
    if (sound) document.getElementById('soundToggle').classList.add('on');
    if (auto)  document.getElementById('autoToggle').classList.add('on');
}

function openDeleteModal()  { document.getElementById('deleteModal').classList.add('open'); }
function closeDeleteModal() { document.getElementById('deleteModal').classList.remove('open'); document.getElementById('delete_password').value = ''; }

document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) closeDeleteModal();
});

function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

window.addEventListener('DOMContentLoaded', function () {
    loadTimerSettings();

    <?php if ($error && (isset($_POST['action']) && $_POST['action'] === 'change_password')): ?>
        switchTab('password', document.querySelectorAll('.settings-tab')[1]);
    <?php elseif ($error && (isset($_POST['action']) && $_POST['action'] === 'delete_account')): ?>
        switchTab('danger', document.querySelectorAll('.settings-tab')[3]);
    <?php endif; ?>
});
</script>

</body>
</html>