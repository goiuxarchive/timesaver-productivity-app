<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

include 'config/db.php';

$user_id = $_SESSION['user_id'];

$stmtWeek = $pdo->prepare("
    SELECT
        DATE(started_at) AS day,
        COUNT(*)         AS session_count,
        SUM(duration)    AS total_minutes
    FROM sessions
    WHERE user_id = :uid
      AND started_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
    GROUP BY DATE(started_at)
    ORDER BY day ASC
");
$stmtWeek->execute([':uid' => $user_id]);
$weekData = $stmtWeek->fetchAll(PDO::FETCH_ASSOC);

$stmtTotals = $pdo->prepare("
    SELECT
        COUNT(*)      AS total_sessions,
        SUM(duration) AS total_minutes,
        MAX(duration) AS longest_session
    FROM sessions
    WHERE user_id = :uid
");
$stmtTotals->execute([':uid' => $user_id]);
$totals = $stmtTotals->fetch(PDO::FETCH_ASSOC);

$stmtTasks = $pdo->prepare("
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) AS completed
    FROM tasks
    WHERE user_id = :uid
");
$stmtTasks->execute([':uid' => $user_id]);
$taskStats = $stmtTasks->fetch(PDO::FETCH_ASSOC);

$stmtHistory = $pdo->prepare("
    SELECT
        s.id,
        s.started_at,
        s.duration,
        s.session_type,
        t.title AS task_title
    FROM sessions s
    LEFT JOIN tasks t ON s.task_id = t.id
    WHERE s.user_id = :uid
    ORDER BY s.started_at DESC
    LIMIT 10
");
$stmtHistory->execute([':uid' => $user_id]);
$history = $stmtHistory->fetchAll(PDO::FETCH_ASSOC);

$stmtStreak = $pdo->prepare("
    SELECT DISTINCT DATE(started_at) AS study_day
    FROM sessions
    WHERE user_id = :uid
    ORDER BY study_day DESC
");
$stmtStreak->execute([':uid' => $user_id]);
$studyDays = $stmtStreak->fetchAll(PDO::FETCH_COLUMN);

$streak = 0;
if (!empty($studyDays)) {
    $check = new DateTime();
    foreach ($studyDays as $day) {
        if ($day === $check->format('Y-m-d')) {
            $streak++;
            $check->modify('-1 day');
        } else { break; }
    }
}

$chartDays = []; $chartSessions = []; $chartMinutes = [];
for ($i = 6; $i >= 0; $i--) {
    $date  = date('Y-m-d', strtotime("-$i days"));
    $chartDays[] = date('D', strtotime($date));
    $found = false;
    foreach ($weekData as $row) {
        if ($row['day'] === $date) {
            $chartSessions[] = (int)$row['session_count'];
            $chartMinutes[]  = (int)($row['total_minutes'] ?? 0);
            $found = true; break;
        }
    }
    if (!$found) { $chartSessions[] = 0; $chartMinutes[] = 0; }
}

$totalSessions  = (int)($totals['total_sessions'] ?? 0);
$totalMinutes   = (int)($totals['total_minutes']  ?? 0);
$totalHours     = round($totalMinutes / 60, 1);
$longestSession = (int)($totals['longest_session'] ?? 0);
$totalTasks     = (int)($taskStats['total']     ?? 0);
$doneTasks      = (int)($taskStats['completed'] ?? 0);
$completionRate = $totalTasks > 0 ? round(($doneTasks / $totalTasks) * 100) : 0;
$weekSessions   = array_sum($chartSessions);
$weekMinutes    = array_sum($chartMinutes);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Progress</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="inner-page">

<?php include 'sidebar.php'; ?>

<div class="main-content">
<div class="progress-page">

    <div class="page-header">
        <div class="page-header-left">
            <div class="page-eyebrow"><i class="fas fa-bolt"></i> Your Journey</div>
            <h1 class="page-title">MY PROGRESS</h1>
            <p class="page-subtitle">See how far you've come. Keep pushing!</p>
        </div>
        <div class="header-date-card">
            <div class="hdc-icon"><i class="fas fa-calendar-days"></i></div>
            <div class="hdc-info">
                <span class="hdc-day"><?= date('l') ?></span>
                <span class="hdc-date"><?= date('F j, Y') ?></span>
            </div>
        </div>
    </div>

    <div class="kpi-grid">
        <div class="kpi-card kpi-streak" style="animation-delay:0.05s">
            <div class="kpi-bg-icon"><i class="fas fa-fire"></i></div>
            <div class="kpi-icon-wrap"><i class="fas fa-fire"></i></div>
            <div class="kpi-info">
                <span class="kpi-val"><?= $streak ?></span>
                <span class="kpi-label">Day Streak</span>
            </div>
        </div>
        <div class="kpi-card kpi-sessions" style="animation-delay:0.10s">
            <div class="kpi-bg-icon"><i class="fas fa-stopwatch"></i></div>
            <div class="kpi-icon-wrap"><i class="fas fa-stopwatch"></i></div>
            <div class="kpi-info">
                <span class="kpi-val"><?= $totalSessions ?></span>
                <span class="kpi-label">Total Sessions</span>
            </div>
        </div>
        <div class="kpi-card kpi-hours" style="animation-delay:0.15s">
            <div class="kpi-bg-icon"><i class="fas fa-clock"></i></div>
            <div class="kpi-icon-wrap"><i class="fas fa-clock"></i></div>
            <div class="kpi-info">
                <span class="kpi-val"><?= $totalHours ?>h</span>
                <span class="kpi-label">Focus Hours</span>
            </div>
        </div>
        <div class="kpi-card kpi-tasks" style="animation-delay:0.20s">
            <div class="kpi-bg-icon"><i class="fas fa-circle-check"></i></div>
            <div class="kpi-icon-wrap"><i class="fas fa-circle-check"></i></div>
            <div class="kpi-info">
                <span class="kpi-val"><?= $completionRate ?>%</span>
                <span class="kpi-label">Task Completion</span>
            </div>
        </div>
    </div>

    <div class="main-grid">

        <!-- Chart Card -->
        <div class="card chart-card">
            <div class="card-header">
                <div class="card-header-left">
                    <div class="card-header-icon"><i class="fas fa-chart-bar"></i></div>
                    <div>
                        <span class="card-title">Sessions This Week</span>
                        <span class="card-sub">Last 7 days activity</span>
                    </div>
                </div>
                <div class="week-pill">
                    <i class="fas fa-bolt"></i>
                    <?= $weekSessions ?> sessions &nbsp;·&nbsp; <?= $weekMinutes ?>m
                </div>
            </div>
            <div class="chart-area">
                <div class="chart-bars" id="chartBars"></div>
                <div class="chart-labels" id="chartLabels"></div>
            </div>
        </div>

        <div class="card weekly-card">
            <div class="card-header">
                <div class="card-header-left">
                    <div class="card-header-icon"><i class="fas fa-calendar-week"></i></div>
                    <div>
                        <span class="card-title">This Week</span>
                        <span class="card-sub">Summary</span>
                    </div>
                </div>
            </div>

            <div class="weekly-stats">
                <div class="weekly-stat">
                    <span class="ws-label">Sessions</span>
                    <span class="ws-val"><?= $weekSessions ?></span>
                </div>
                <div class="weekly-stat">
                    <span class="ws-label">Focus Time</span>
                    <span class="ws-val"><?= $weekMinutes ?>m</span>
                </div>
                <div class="weekly-stat">
                    <span class="ws-label">Daily Avg</span>
                    <span class="ws-val"><?= round($weekSessions / 7, 1) ?></span>
                </div>
                <div class="weekly-stat">
                    <span class="ws-label">Longest</span>
                    <span class="ws-val"><?= $longestSession ?>m</span>
                </div>
            </div>

            <div class="task-progress-wrap">
                <div class="tp-header">
                    <span>Task Completion</span>
                    <span class="tp-fraction"><?= $doneTasks ?> / <?= $totalTasks ?></span>
                </div>
                <div class="progress-track">
                    <div class="progress-fill" style="width:<?= $completionRate ?>%"></div>
                </div>
                <span class="tp-pct"><?= $completionRate ?>% complete</span>
            </div>
        </div>

    </div>

    <div class="card history-card">
        <div class="card-header">
            <div class="card-header-left">
                <div class="card-header-icon"><i class="fas fa-history"></i></div>
                <div>
                    <span class="card-title">Session History</span>
                    <span class="card-sub">Last 10 sessions</span>
                </div>
            </div>
        </div>

        <?php if (empty($history)): ?>
            <div class="empty-state">
                <div class="empty-blob"></div>
                <div class="empty-icon"><i class="fas fa-chart-bar"></i></div>
                <h3>No sessions yet!</h3>
                <p>Complete a Pomodoro on the <a href="timer.php">Timer</a> page to see your history here!</p>
            </div>
        <?php else: ?>
        <div class="table-scroll">
            <table class="history-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date & Time</th>
                        <th>Type</th>
                        <th>Duration</th>
                        <th>Task</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($history as $i => $s): ?>
                    <tr style="animation-delay:<?= $i * 0.04 ?>s">
                        <td class="td-num"><?= $i + 1 ?></td>
                        <td class="td-date">
                            <?php $dt = new DateTime($s['started_at']); ?>
                            <span class="date-main"><?= $dt->format('M d, Y') ?></span>
                            <span class="date-time"><?= $dt->format('g:i A') ?></span>
                        </td>
                        <td>
                            <?php
                                $type = $s['session_type'] ?? 'focus';
                                $typeClass = ['focus'=>'type-focus','short_break'=>'type-short','long_break'=>'type-long'][$type] ?? 'type-focus';
                                $typeLabel = ['focus'=>'<i class="fas fa-brain"></i> Focus','short_break'=>'<i class="fas fa-coffee"></i> Short Break','long_break'=>'<i class="fas fa-couch"></i> Long Break'][$type] ?? '<i class="fas fa-brain"></i> Focus';
                            ?>
                            <span class="type-badge <?= $typeClass ?>"><?= $typeLabel ?></span>
                        </td>
                        <td>
                            <span class="duration-chip"><?= $s['duration'] ?? 25 ?>m</span>
                        </td>
                        <td>
                            <?php if (!empty($s['task_title'])): ?>
                                <span class="task-chip"><?= htmlspecialchars($s['task_title']) ?></span>
                            <?php else: ?>
                                <span class="td-muted">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <div class="records-grid">
        <div class="record-card" style="animation-delay:0.05s">
            <div class="record-icon-wrap record-icon--gold"><i class="fas fa-trophy"></i></div>
            <div class="record-info">
                <span class="record-val"><?= $totalSessions ?></span>
                <span class="record-label">All-Time Sessions</span>
            </div>
            <div class="record-bg-icon"><i class="fas fa-trophy"></i></div>
        </div>
        <div class="record-card" style="animation-delay:0.10s">
            <div class="record-icon-wrap record-icon--red"><i class="fas fa-hourglass-end"></i></div>
            <div class="record-info">
                <span class="record-val"><?= $totalHours ?>h</span>
                <span class="record-label">Total Hours Studied</span>
            </div>
            <div class="record-bg-icon"><i class="fas fa-hourglass-end"></i></div>
        </div>
        <div class="record-card" style="animation-delay:0.15s">
            <div class="record-icon-wrap record-icon--blue"><i class="fas fa-bolt"></i></div>
            <div class="record-info">
                <span class="record-val"><?= $longestSession ?>m</span>
                <span class="record-label">Longest Session</span>
            </div>
            <div class="record-bg-icon"><i class="fas fa-bolt"></i></div>
        </div>
        <div class="record-card" style="animation-delay:0.20s">
            <div class="record-icon-wrap record-icon--green"><i class="fas fa-list-check"></i></div>
            <div class="record-info">
                <span class="record-val"><?= $doneTasks ?></span>
                <span class="record-label">Tasks Completed</span>
            </div>
            <div class="record-bg-icon"><i class="fas fa-list-check"></i></div>
        </div>
    </div>

</div>
</div>

<style>
.progress-page {
    padding: 36px 40px 60px;
    max-width: 1100px;
    margin: 0 auto;
    width: 100%;
}

.page-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 28px;
    gap: 20px;
    flex-wrap: wrap;
}

.page-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #c0392b;
    background: rgba(192,57,43,0.08);
    padding: 4px 12px;
    border-radius: 99px;
    margin-bottom: 10px;
}

.page-title {
    font-family: 'Inter', sans-serif;
    font-size: 36px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -1.5px;
    line-height: 1;
    margin-bottom: 6px;
}

.page-subtitle {
    font-size: 15px;
    color: #999;
}

.header-date-card {
    display: flex;
    align-items: center;
    gap: 14px;
    background: linear-gradient(135deg, #1a1a2e, #2d2d44);
    border-radius: 18px;
    padding: 14px 20px;
    box-shadow: 0 8px 24px rgba(26,26,46,0.2);
    min-width: 180px;
}

.hdc-icon {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    background: rgba(192,57,43,0.25);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    color: #ff6b6b;
    flex-shrink: 0;
}

.hdc-info { display: flex; flex-direction: column; gap: 2px; }

.hdc-day {
    font-family: 'Syne', sans-serif;
    font-size: 15px;
    font-weight: 800;
    color: #fff;
    letter-spacing: -0.3px;
}

.hdc-date {
    font-size: 11px;
    color: rgba(255,255,255,0.45);
    font-weight: 600;
}

.kpi-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 24px;
}

.kpi-card {
    border-radius: 22px;
    padding: 22px 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    position: relative;
    overflow: hidden;
    transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.25s ease;
    animation: cardPop 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
    cursor: default;
}

.kpi-card:hover { transform: translateY(-6px) scale(1.02); }

.kpi-streak  { background: linear-gradient(135deg, #c0392b, #e74c3c); box-shadow: 0 8px 32px rgba(192,57,43,0.3); }
.kpi-sessions{ background: linear-gradient(135deg, #1a1a2e, #2d2d44); box-shadow: 0 8px 32px rgba(26,26,46,0.25); }
.kpi-hours   { background: linear-gradient(135deg, #1a6fa6, #2980b9); box-shadow: 0 8px 32px rgba(41,128,185,0.3); }
.kpi-tasks   { background: linear-gradient(135deg, #1e8449, #27ae60); box-shadow: 0 8px 32px rgba(39,174,96,0.3); }

.kpi-streak:hover  { box-shadow: 0 16px 48px rgba(192,57,43,0.45); }
.kpi-sessions:hover{ box-shadow: 0 16px 48px rgba(26,26,46,0.4); }
.kpi-hours:hover   { box-shadow: 0 16px 48px rgba(41,128,185,0.45); }
.kpi-tasks:hover   { box-shadow: 0 16px 48px rgba(39,174,96,0.45); }

.kpi-bg-icon {
    position: absolute;
    right: -10px;
    bottom: -10px;
    font-size: 80px;
    color: rgba(255,255,255,0.07);
    pointer-events: none;
    line-height: 1;
}

.kpi-icon-wrap {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    background: rgba(255,255,255,0.16);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 19px;
    color: #fff;
    flex-shrink: 0;
    z-index: 1;
    backdrop-filter: blur(4px);
}

.kpi-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
    z-index: 1;
}

.kpi-val {
    font-family: 'Syne', sans-serif;
    font-size: 36px;
    font-weight: 800;
    color: #fff;
    line-height: 1;
    letter-spacing: -2px;
}

.kpi-label {
    font-size: 11px;
    font-weight: 700;
    color: rgba(255,255,255,0.6);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.card {
    background: #fff;
    border-radius: 22px;
    border: 2px solid #f0f0f0;
    box-shadow: 0 4px 24px rgba(0,0,0,0.06);
    overflow: hidden;
}

.card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 22px;
    border-bottom: 1px solid #f5f5f5;
    background: #fafafa;
    gap: 12px;
    flex-wrap: wrap;
}

.card-header-left {
    display: flex;
    align-items: center;
    gap: 12px;
}

.card-header-icon {
    width: 38px;
    height: 38px;
    border-radius: 11px;
    background: linear-gradient(135deg, rgba(192,57,43,0.1), rgba(231,76,60,0.15));
    border: 1px solid rgba(192,57,43,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    color: #c0392b;
    flex-shrink: 0;
}

.card-title {
    font-family: 'Syne', sans-serif;
    display: block;
    font-size: 15px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -0.3px;
}

.card-sub {
    display: block;
    font-size: 12px;
    color: #bbb;
    margin-top: 1px;
    font-weight: 500;
}

.main-grid {
    display: grid;
    grid-template-columns: 1fr 300px;
    gap: 20px;
    margin-bottom: 24px;
}

.week-pill {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    font-weight: 700;
    color: #888;
    background: #f0f0f0;
    padding: 6px 14px;
    border-radius: 99px;
    white-space: nowrap;
}

.week-pill i { color: #c0392b; font-size: 11px; }

.chart-area {
    padding: 28px 22px 16px;
}

.chart-bars {
    display: flex;
    align-items: flex-end;
    gap: 10px;
    height: 160px;
    padding-bottom: 10px;
    border-bottom: 2px solid #f0f0f0;
}

.chart-bar-wrap {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    height: 100%;
    justify-content: flex-end;
}

.bar-count {
    font-size: 11px;
    font-weight: 800;
    color: #bbb;
    font-family: 'Space Mono', monospace;
    min-height: 14px;
}

.chart-bar {
    width: 100%;
    border-radius: 10px 10px 0 0;
    background: linear-gradient(180deg, #2d2d44, #1a1a2e);
    transition: height 0.8s cubic-bezier(0.34,1.2,0.64,1);
    position: relative;
    cursor: pointer;
    min-height: 4px;
}

.chart-bar.today {
    background: linear-gradient(180deg, #e74c3c, #c0392b);
    box-shadow: 0 -4px 16px rgba(192,57,43,0.3);
}

.chart-bar.zero {
    background: #f0f0f0;
    min-height: 4px;
}

.chart-bar:hover::after {
    content: attr(data-tip);
    position: absolute;
    bottom: calc(100% + 8px);
    left: 50%;
    transform: translateX(-50%);
    background: #1a1a1a;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    padding: 5px 10px;
    border-radius: 8px;
    white-space: nowrap;
    font-family: 'Inter', sans-serif;
    pointer-events: none;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.chart-labels {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}

.chart-label {
    flex: 1;
    text-align: center;
    font-size: 11px;
    font-weight: 700;
    color: #ccc;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.chart-label.today {
    color: #c0392b;
    font-size: 10px;
}

.weekly-stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
}

.weekly-stat {
    padding: 18px 20px;
    border-bottom: 1px solid #f5f5f5;
    border-right: 1px solid #f5f5f5;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.weekly-stat:nth-child(even)       { border-right: none; }
.weekly-stat:nth-child(3),
.weekly-stat:nth-child(4)          { border-bottom: none; }

.ws-label {
    font-size: 10px;
    font-weight: 700;
    color: #ccc;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.ws-val {
    font-family: 'Syne', sans-serif;
    font-size: 26px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -1px;
    line-height: 1;
}

.task-progress-wrap {
    padding: 18px 20px;
    border-top: 1px solid #f5f5f5;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.tp-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    font-weight: 700;
    color: #333;
}

.tp-fraction {
    font-family: 'Space Mono', monospace;
    font-size: 12px;
    color: #bbb;
}

.progress-track {
    height: 10px;
    background: #f0f0f0;
    border-radius: 99px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #c0392b, #e74c3c);
    border-radius: 99px;
    transition: width 1.2s cubic-bezier(0.34,1.2,0.64,1);
    box-shadow: 0 2px 8px rgba(192,57,43,0.3);
}

.tp-pct {
    font-size: 12px;
    color: #bbb;
    font-weight: 600;
}


.table-scroll { overflow-x: auto; }

.history-table {
    width: 100%;
    border-collapse: collapse;
}

.history-table thead tr {
    background: linear-gradient(135deg, #1a1a1a, #2d2d2d);
}

.history-table th {
    padding: 13px 18px;
    font-size: 11px;
    font-weight: 700;
    color: rgba(255,255,255,0.45);
    text-transform: uppercase;
    letter-spacing: 1px;
    text-align: left;
    white-space: nowrap;
}

.history-table td {
    padding: 15px 18px;
    font-size: 13px;
    color: #333;
    border-bottom: 1px solid #f5f5f5;
    vertical-align: middle;
}

.history-table tbody tr {
    transition: background 0.15s ease;
    animation: rowSlideIn 0.4s ease both;
}

.history-table tbody tr:last-child td { border-bottom: none; }
.history-table tbody tr:hover { background: #fafafa; }

.td-num {
    color: #ddd;
    font-family: 'Space Mono', monospace;
    font-size: 12px;
    text-align: center;
}

.td-date {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.date-main {
    font-size: 13px;
    font-weight: 700;
    color: #1a1a1a;
}

.date-time {
    font-size: 11px;
    color: #bbb;
    font-weight: 500;
}

.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 12px;
    border-radius: 99px;
    font-size: 12px;
    font-weight: 700;
    white-space: nowrap;
}

.type-focus { background: rgba(192,57,43,0.1); color: #800517; border: 1px solid rgba(192,57,43,0.15); }
.type-short { background: rgba(39,174,96,0.1);  color: #1e8449; border: 1px solid rgba(39,174,96,0.15); }
.type-long  { background: rgba(52,152,219,0.1); color: #1a6fa6; border: 1px solid rgba(52,152,219,0.15); }

.duration-chip {
    display: inline-block;
    background: #f5f5f5;
    color: #333;
    font-family: 'Space Mono', monospace;
    font-size: 13px;
    font-weight: 700;
    padding: 4px 12px;
    border-radius: 99px;
    border: 1px solid #ebebeb;
}

.task-chip {
    display: inline-block;
    padding: 4px 12px;
    background: rgba(192,57,43,0.06);
    color: #800517;
    border-radius: 99px;
    font-size: 12px;
    font-weight: 700;
    max-width: 180px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    border: 1px solid rgba(192,57,43,0.1);
}

.td-muted { color: #ddd; font-size: 13px; }

.records-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
}

.record-card {
    background: #fff;
    border-radius: 20px;
    border: 2px solid #f0f0f0;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    position: relative;
    overflow: hidden;
    transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.25s ease;
    animation: cardPop 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
    box-shadow: 0 4px 16px rgba(0,0,0,0.05);
}

.record-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 32px rgba(0,0,0,0.1);
    border-color: #e8e8e8;
}

.record-bg-icon {
    position: absolute;
    right: -8px;
    bottom: -8px;
    font-size: 60px;
    pointer-events: none;
    opacity: 0.04;
    color: #1a1a1a;
}

.record-icon-wrap {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    flex-shrink: 0;
    z-index: 1;
}

.record-icon--gold  { background: rgba(214,137,16,0.12);  color: #b7770d; border: 1px solid rgba(214,137,16,0.2); }
.record-icon--red   { background: rgba(192,57,43,0.1);    color: #800517; border: 1px solid rgba(192,57,43,0.15); }
.record-icon--blue  { background: rgba(52,152,219,0.1);   color: #1a6fa6; border: 1px solid rgba(52,152,219,0.15); }
.record-icon--green { background: rgba(39,174,96,0.1);    color: #1e8449; border: 1px solid rgba(39,174,96,0.15); }

.record-info {
    display: flex;
    flex-direction: column;
    gap: 3px;
    z-index: 1;
}

.record-val {
    font-family: 'Syne', sans-serif;
    font-size: 26px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -1px;
    line-height: 1;
}

.record-label {
    font-size: 12px;
    color: #aaa;
    font-weight: 600;
    line-height: 1.3;
}

.empty-state {
    padding: 70px 20px;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    position: relative;
    overflow: hidden;
}

.empty-blob {
    position: absolute;
    width: 280px;
    height: 280px;
    background: radial-gradient(circle, rgba(192,57,43,0.05) 0%, transparent 70%);
    border-radius: 50%;
    top: 50%; left: 50%;
    transform: translate(-50%,-50%);
    pointer-events: none;
}

.empty-icon {
    width: 76px;
    height: 76px;
    background: linear-gradient(135deg, rgba(192,57,43,0.1), rgba(231,76,60,0.15));
    border-radius: 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    color: #c0392b;
    margin-bottom: 4px;
    border: 2px solid rgba(192,57,43,0.1);
}

.empty-state h3 {
    font-family: 'Syne', sans-serif;
    font-size: 22px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -0.5px;
}

.empty-state p  { font-size: 14px; color: #aaa; line-height: 1.6; }
.empty-state a  { color: #c0392b; font-weight: 700; text-decoration: none; }
.empty-state a:hover { text-decoration: underline; }

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(24px); }
    to   { opacity: 1; transform: translateY(0); }
}

@keyframes cardPop {
    from { opacity: 0; transform: translateY(20px) scale(0.95); }
    to   { opacity: 1; transform: translateY(0)    scale(1);    }
}

@keyframes rowSlideIn {
    from { opacity: 0; transform: translateX(-10px); }
    to   { opacity: 1; transform: translateX(0); }
}

@media (max-width: 900px) {
    .kpi-grid     { grid-template-columns: repeat(2,1fr); }
    .main-grid    { grid-template-columns: 1fr; }
    .records-grid { grid-template-columns: repeat(2,1fr); }
    .weekly-card  { max-width: 500px; }
}

@media (max-width: 768px) {
    .progress-page { padding: 20px 16px 40px; }
    .page-header   { flex-direction: column; gap: 12px; }
    .page-title    { font-size: 28px; }
    .history-table { display: block; overflow-x: auto; }
}

@media (max-width: 600px) {
    .kpi-grid      { grid-template-columns: repeat(2,1fr); gap: 10px; }
    .records-grid  { grid-template-columns: repeat(2,1fr); gap: 10px; }
    .kpi-val       { font-size: 28px; }
    .history-table th:nth-child(5),
    .history-table td:nth-child(5) { display: none; }
}

@media (max-width: 480px) {
    .kpi-grid      { gap: 8px; }
    .records-grid  { grid-template-columns: 1fr 1fr; gap: 8px; }
    .kpi-val       { font-size: 24px; }
    .history-table th:nth-child(4),
    .history-table td:nth-child(4) { display: none; }
}
</style>

<script>
const sessions = <?= json_encode($chartSessions) ?>;
const minutes  = <?= json_encode($chartMinutes)  ?>;
const days     = <?= json_encode($chartDays)     ?>;
const todayIdx = 6;

const barsEl   = document.getElementById('chartBars');
const labelsEl = document.getElementById('chartLabels');
const maxVal   = Math.max(...sessions, 1);

days.forEach((day, i) => {
    const count   = sessions[i];
    const mins    = minutes[i];
    const isToday = i === todayIdx;
    const pct     = count === 0 ? 2.5 : Math.max((count / maxVal) * 100, 4);

    const wrap = document.createElement('div');
    wrap.className = 'chart-bar-wrap';

    const countEl = document.createElement('span');
    countEl.className   = 'bar-count';
    countEl.textContent = count > 0 ? count : '';

    const bar = document.createElement('div');
    bar.className = 'chart-bar'
        + (isToday ? ' today' : '')
        + (count === 0 ? ' zero' : '');
    bar.style.height = '0%';
    bar.setAttribute('data-tip', `${count} session${count !== 1 ? 's' : ''} · ${mins}m`);

    wrap.appendChild(countEl);
    wrap.appendChild(bar);
    barsEl.appendChild(wrap);

    setTimeout(() => { bar.style.height = pct + '%'; }, 100 + i * 80);

    const lbl = document.createElement('div');
    lbl.className   = 'chart-label' + (isToday ? ' today' : '');
    lbl.textContent = isToday ? 'Today' : day;
    labelsEl.appendChild(lbl);
});
</script>

</body>
</html>