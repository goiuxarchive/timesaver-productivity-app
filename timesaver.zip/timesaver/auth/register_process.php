<?php
session_start();
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../register.php');
    exit;
}

$first_name = trim($_POST['first_name']       ?? '');
$last_name  = trim($_POST['last_name']        ?? '');
$email      = trim($_POST['email']            ?? '');
$password   = trim($_POST['password']         ?? '');
$confirm    = trim($_POST['confirm_password'] ?? '');

if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($confirm)) {
    header('Location: ../register.php?error=empty');
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: ../register.php?error=invalid_email');
    exit;
}

if (strlen($password) < 8) {
    header('Location: ../register.php?error=weak');
    exit;
}

if ($password !== $confirm) {
    header('Location: ../register.php?error=mismatch');
    exit;
}

$chk = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
$chk->execute([':email' => $email]);
if ($chk->fetch()) {
    header('Location: ../register.php?error=exists');
    exit;
}

$hashed = password_hash($password, PASSWORD_DEFAULT);

$ins = $pdo->prepare("
    INSERT INTO users (first_name, last_name, email, password)
    VALUES (:fn, :ln, :em, :pw)
");
$ins->execute([
    ':fn' => $first_name,
    ':ln' => $last_name,
    ':em' => $email,
    ':pw' => $hashed,
]);

header('Location: ../login.php?registered=1');
exit;