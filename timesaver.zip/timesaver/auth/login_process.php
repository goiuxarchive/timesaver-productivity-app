<?php
session_start();
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php');
    exit;
}

$email    = trim($_POST['email']    ?? '');
$password = trim($_POST['password'] ?? '');

if (empty($email) || empty($password)) {
    header('Location: ../login.php?error=empty');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
$stmt->execute([':email' => $email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    header('Location: ../login.php?error=invalid');
    exit;
}

$_SESSION['user_id']    = $user['id'];
$_SESSION['first_name'] = $user['first_name'];
$_SESSION['last_name']  = $user['last_name'];
$_SESSION['email']      = $user['email'];

if (!empty($_POST['remember'])) {
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+30 days'));

    $pdo->prepare("DELETE FROM remember_tokens WHERE user_id = :uid")
        ->execute([':uid' => $user['id']]);

    $pdo->prepare("
        INSERT INTO remember_tokens (user_id, token, expires_at)
        VALUES (:uid, :token, :expires)
    ")->execute([
        ':uid'     => $user['id'],
        ':token'   => $token,
        ':expires' => $expires,
    ]);

    setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/', '', true, true);
}

header('Location: ../timer.php');
exit;