<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register – TimeSaver</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            min-height: 100vh;
            background-color: #f0f2f5;
            display: flex;
            overflow: hidden;
        }

        .left-panel {
            width: 45%;
            background-color: #800517;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px;
            position: relative;
            overflow: hidden;
            animation: slideInLeft 0.7s cubic-bezier(0.34, 1.2, 0.64, 1) forwards;
        }

        .left-panel::before {
            content: '';
            position: absolute;
            width: 420px;
            height: 420px;
            border-radius: 50%;
            border: 60px solid rgba(255,255,255,0.07);
            top: -120px;
            left: -120px;
        }

        .left-panel::after {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            border: 50px solid rgba(255,255,255,0.07);
            bottom: -80px;
            right: -80px;
        }

        .left-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 32px;
            z-index: 1;
            text-align: center;
        }

        .logo-wrap {
            display: flex;
            align-items: center;
            gap: 14px;
            animation: fadeUp 0.6s ease 0.2s both;
        }

        .logo-wrap img {
            width: 150px;
            height: 200px;
            object-fit: contain;
            border-radius: 14px;
        }

        .brand-name {
            font-size: 44px;
            font-weight: 900;
            color: #ffffff;
            letter-spacing: -2px;
            line-height: 1;
        }

        .left-tagline {
            font-size: 20px;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.4;
            animation: fadeUp 0.6s ease 0.35s both;
        }

        .left-tagline span {
            display: block;
            font-size: 14px;
            font-weight: 400;
            color: rgba(255,255,255,0.7);
            margin-top: 8px;
        }

        .info-cards {
            display: flex;
            flex-direction: column;
            gap: 12px;
            width: 100%;
            max-width: 320px;
            animation: fadeUp 0.6s ease 0.5s both;
        }

        .info-card {
            background: rgba(255,255,255,0.12);
            border-radius: 12px;
            padding: 14px 18px;
            display: flex;
            align-items: center;
            gap: 14px;
            text-align: left;
        }

        .info-card .ic-icon {
            width: 38px;
            height: 38px;
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .info-card .ic-icon i {
            font-size: 16px;
            color: #ffffff;
        }

        .info-card .ic-text {
            font-size: 13px;
            color: #fff;
            font-weight: 500;
            line-height: 1.4;
        }

        .info-card .ic-text small {
            display: block;
            font-weight: 400;
            color: rgba(255,255,255,0.65);
            font-size: 12px;
            margin-top: 2px;
        }

        .right-panel {
            width: 55%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 50px 50px;
            overflow-y: auto;
            animation: slideInRight 0.7s cubic-bezier(0.34, 1.2, 0.64, 1) forwards;
        }

        .form-box {
            width: 100%;
            max-width: 420px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .form-header {
            display: flex;
            flex-direction: column;
            gap: 6px;
            animation: fadeUp 0.6s ease 0.3s both;
        }

        .form-header h1 {
            font-size: 30px;
            font-weight: 900;
            color: #1a1a1a;
            letter-spacing: -1px;
        }

        .form-header h1 span {
            color: #800517;
        }

        .form-header p {
            font-size: 14px;
            color: #888;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert.error {
            background: #fdecea;
            color: #800517;
            border: 1px solid #f5c6c2;
        }

        .alert.success {
            background: #eafaf1;
            color: #1e8449;
            border: 1px solid #a9dfbf;
        }

        .form-row {
            display: flex;
            gap: 14px;
            animation: fadeUp 0.6s ease 0.4s both;
        }

        .form-row .form-group {
            flex: 1;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
            animation: fadeUp 0.6s ease 0.4s both;
        }

        .form-group label {
            font-size: 13px;
            font-weight: 600;
            color: #333;
        }

        .input-wrap {
            position: relative;
        }

        .input-wrap .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 14px;
            color: #aaa;
            pointer-events: none;
        }

        .form-group input {
            width: 100%;
            padding: 14px 14px 14px 42px;
            border: 2px solid #e5e5e5;
            border-radius: 12px;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            color: #1a1a1a;
            background: #fff;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
            outline: none;
        }

        .form-group input:focus {
            border-color: #800517;
            box-shadow: 0 0 0 4px rgba(192, 57, 43, 0.1);
        }

        .form-group input::placeholder {
            color: #bbb;
        }

        .form-group input.invalid {
            border-color: #e74c3c;
            box-shadow: 0 0 0 4px rgba(231, 76, 60, 0.1);
        }

        .toggle-pw {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            font-size: 14px;
            color: #aaa;
            padding: 0;
            transition: color 0.2s ease;
        }

        .toggle-pw:hover { color: #800517; }

        .pw-strength {
            display: flex;
            gap: 5px;
            margin-top: 6px;
        }

        .pw-strength-bar {
            flex: 1;
            height: 4px;
            border-radius: 99px;
            background: #e5e5e5;
            transition: background 0.3s ease;
        }

        .pw-strength-label {
            font-size: 11px;
            font-weight: 600;
            margin-top: 4px;
            color: #aaa;
            transition: color 0.3s ease;
        }

        .terms-check {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            font-size: 13px;
            color: #555;
            animation: fadeUp 0.6s ease 0.55s both;
        }

        .terms-check input[type="checkbox"] {
            accent-color: #800517;
            width: 15px;
            height: 15px;
            cursor: pointer;
            margin-top: 1px;
            flex-shrink: 0;
        }

        .terms-check a {
            color: #800517;
            text-decoration: none;
            font-weight: 500;
        }

        .terms-check a:hover { text-decoration: underline; }

        .btn-register {
            width: 100%;
            padding: 16px;
            background: #800517;
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s ease, transform 0.15s ease, box-shadow 0.2s ease;
            box-shadow: 0 4px 20px rgba(192, 57, 43, 0.35);
            animation: fadeUp 0.6s ease 0.6s both;
            font-family: 'Inter', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-register:hover {
            background: #a93226;
            transform: translateY(-2px);
            box-shadow: 0 8px 28px rgba(192, 57, 43, 0.45);
        }

        .btn-register:active { transform: translateY(0); }

        .login-link {
            text-align: center;
            font-size: 13px;
            color: #888;
            animation: fadeUp 0.6s ease 0.7s both;
        }

        .login-link a {
            color: #800517;
            font-weight: 600;
            text-decoration: none;
        }

        .login-link a:hover { text-decoration: underline; }

        @keyframes slideInLeft {
            from { transform: translateX(-40px); opacity: 0; }
            to   { transform: translateX(0);     opacity: 1; }
        }

        @keyframes slideInRight {
            from { transform: translateX(40px); opacity: 0; }
            to   { transform: translateX(0);    opacity: 1; }
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0);    }
        }
    </style>
</head>
<body>

<div class="left-panel">
    <div class="left-content">

        <div class="logo-wrap">
            <img src="assets/images/logo.png" alt="TimeSaver Logo">
            <span class="brand-name">TimeSaver</span>
        </div>

        <div class="left-tagline">
            Join TimeSaver!
        </div>

        <div class="info-cards">
            <div class="info-card">
                <div class="ic-icon"><i class="fas fa-stopwatch"></i></div>
                <div class="ic-text">
                    Pomodoro Timer
                    <small>25-minute focus sessions with short breaks</small>
                </div>
            </div>
            <div class="info-card">
                <div class="ic-icon"><i class="fas fa-tasks"></i></div>
                <div class="ic-text">
                    Task Manager
                    <small>Add, track, and complete your study tasks</small>
                </div>
            </div>
            <div class="info-card">
                <div class="ic-icon"><i class="fas fa-chart-bar"></i></div>
                <div class="ic-text">
                    Progress Tracker
                    <small>View your weekly study session history</small>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="right-panel">
    <div class="form-box">

        <div class="form-header">
            <h1>Create your<span> Account</span></h1>
            <p>Fill in the details below to get started.</p>
        </div>

        <?php if (isset($_GET['error'])): ?>
            <div class="alert error">
                <i class="fas fa-circle-exclamation"></i>
                <?php
                    $err = $_GET['error'];
                    if ($err === 'exists')        echo 'An account with that email already exists.';
                    elseif ($err === 'mismatch')  echo 'Passwords do not match. Please try again.';
                    elseif ($err === 'empty')     echo 'Please fill in all required fields.';
                    elseif ($err === 'weak')      echo 'Password must be at least 8 characters long.';
                    else                          echo 'An error occurred. Please try again.';
                ?>
            </div>
        <?php endif; ?>

        <form action="auth/register_process.php" method="POST" id="registerForm">

            <div class="form-row">
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <div class="input-wrap">
                        <i class="fas fa-user input-icon"></i>
                        <input
                            type="text"
                            id="first_name"
                            name="first_name"
                            required
                            autocomplete="given-name"
                        >
                    </div>
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <div class="input-wrap">
                        <i class="fas fa-user input-icon"></i>
                        <input
                            type="text"
                            id="last_name"
                            name="last_name"
                            required
                            autocomplete="family-name"
                        >
                    </div>
                </div>
            </div>

            <br>

            <div class="form-group">
                <label for="email">Email Address</label>
                <div class="input-wrap">
                    <i class="fas fa-envelope input-icon"></i>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        autocomplete="email"
                    >
                </div>
            </div>

            <br>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock input-icon"></i>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        required
                        autocomplete="new-password"
                        oninput="checkStrength(this.value)"
                    >
                    <button type="button" class="toggle-pw" onclick="togglePassword('password', 'toggleIcon1')">
                        <i class="fas fa-eye" id="toggleIcon1"></i>
                    </button>
                </div>
                <div class="pw-strength" id="strengthBars">
                    <div class="pw-strength-bar" id="bar1"></div>
                    <div class="pw-strength-bar" id="bar2"></div>
                    <div class="pw-strength-bar" id="bar3"></div>
                    <div class="pw-strength-bar" id="bar4"></div>
                </div>
                <span class="pw-strength-label" id="strengthLabel"></span>
            </div>

            <br>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock input-icon"></i>
                    <input
                        type="password"
                        id="confirm_password"
                        name="confirm_password"
                        placeholder="Confirm Password"
                        required
                        autocomplete="new-password"
                    >
                    <button type="button" class="toggle-pw" onclick="togglePassword('confirm_password', 'toggleIcon2')">
                        <i class="fas fa-eye" id="toggleIcon2"></i>
                    </button>
                </div>
            </div>

            <br>

            <div class="terms-check">
                <input type="checkbox" id="terms" name="terms" required>
                <label for="terms">
                    I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
                </label>
            </div>

            <br>

            <button type="submit" class="btn-register" id="submitBtn">
                <i class="fas fa-user-plus"></i> Create Account
            </button>

        </form>

        <p class="login-link">
            Already have an account? <a href="login.php">Sign in</a>
        </p>

    </div>
</div>

<script>
    function togglePassword(fieldId, iconId) {
        const pw   = document.getElementById(fieldId);
        const icon = document.getElementById(iconId);
        if (pw.type === 'password') {
            pw.type = 'text';
            icon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            pw.type = 'password';
            icon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }

    function checkStrength(value) {
        const bars  = [
            document.getElementById('bar1'),
            document.getElementById('bar2'),
            document.getElementById('bar3'),
            document.getElementById('bar4')
        ];
        const label = document.getElementById('strengthLabel');

        bars.forEach(b => b.style.background = '#e5e5e5');

        if (!value) { label.textContent = ''; return; }

        let score = 0;
        if (value.length >= 8)               score++;
        if (/[A-Z]/.test(value))             score++;
        if (/[0-9]/.test(value))             score++;
        if (/[^A-Za-z0-9]/.test(value))      score++;

        const colors = ['#e74c3c', '#e67e22', '#f1c40f', '#27ae60'];
        const labels = ['Weak', 'Fair', 'Good', 'Strong'];

        for (let i = 0; i < score; i++) {
            bars[i].style.background = colors[score - 1];
        }

        label.textContent  = labels[score - 1] || '';
        label.style.color  = colors[score - 1] || '#aaa';
    }

    document.getElementById('registerForm').addEventListener('submit', function(e) {
        const pw      = document.getElementById('password').value;
        const confirm = document.getElementById('confirm_password').value;
        const confirmField = document.getElementById('confirm_password');

        if (pw !== confirm) {
            e.preventDefault();
            confirmField.classList.add('invalid');
            confirmField.focus();
            alert('Passwords do not match. Please try again.');
        } else {
            confirmField.classList.remove('invalid');
        }

        if (pw.length < 8) {
            e.preventDefault();
            document.getElementById('password').classList.add('invalid');
            alert('Password must be at least 8 characters.');
        }
    });
</script>

</body>
</html>