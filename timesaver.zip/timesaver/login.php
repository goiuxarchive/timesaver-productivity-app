<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            min-height: 100vh;
            background-color: #f0f2f5;
            display: flex;
            overflow: hidden;
        }

        .left-panel {
            width: 45%;
            background-color: #800517;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px;
            position: relative;
            overflow: hidden;
            animation: slideInLeft 0.7s cubic-bezier(0.34, 1.2, 0.64, 1) forwards;
        }

        .left-panel::before {
            content: '';
            position: absolute;
            width: 420px;
            height: 420px;
            border-radius: 50%;
            border: 60px solid rgba(255,255,255,0.07);
            top: -120px;
            left: -120px;
        }

        .left-panel::after {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            border: 50px solid rgba(255,255,255,0.07);
            bottom: -80px;
            right: -80px;
        }

        .left-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 32px;
            z-index: 1;
            text-align: center;
        }

        .logo-wrap {
            display: flex;
            align-items: center;
            gap: 14px;
            animation: fadeUp 0.6s ease 0.2s both;
        }

        .logo-wrap img {
            width: 150px;
            height: 200px;
            object-fit: contain;
            border-radius: 14px;
        }

        .brand-name {
            font-size: 44px;
            font-weight: 900;
            color: #ffffff;
            letter-spacing: -2px;
            line-height: 1;
        }

        .left-tagline {
            font-size: 20px;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.4;
            animation: fadeUp 0.6s ease 0.35s both;
        }

        .left-tagline span {
            display: block;
            font-size: 14px;
            font-weight: 400;
            color: rgba(255,255,255,0.7);
            margin-top: 8px;
        }

        .info-cards {
            display: flex;
            flex-direction: column;
            gap: 12px;
            width: 100%;
            max-width: 320px;
            animation: fadeUp 0.6s ease 0.5s both;
        }

        .info-card {
            background: rgba(255,255,255,0.12);
            border-radius: 12px;
            padding: 14px 18px;
            display: flex;
            align-items: center;
            gap: 14px;
            text-align: left;
        }

        .info-card .ic-icon {
            width: 38px;
            height: 38px;
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .info-card .ic-icon i {
            font-size: 16px;
            color: #ffffff;
        }

        .info-card .ic-text {
            font-size: 13px;
            color: #fff;
            font-weight: 500;
            line-height: 1.4;
        }

        .info-card .ic-text small {
            display: block;
            font-weight: 400;
            color: rgba(255,255,255,0.65);
            font-size: 12px;
            margin-top: 2px;
        }

        .right-panel {
            width: 55%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px 50px;
            animation: slideInRight 0.7s cubic-bezier(0.34, 1.2, 0.64, 1) forwards;
        }

        .form-box {
            width: 100%;
            max-width: 420px;
            display: flex;
            flex-direction: column;
            gap: 24px;
        }

        .form-header {
            display: flex;
            flex-direction: column;
            gap: 6px;
            animation: fadeUp 0.6s ease 0.3s both;
        }

        .form-header h1 {
            font-size: 30px;
            font-weight: 900;
            color: #1a1a1a;
            letter-spacing: -1px;
        }

        .form-header h1 span {
            color: #800517;
        }

        .form-header p {
            font-size: 14px;
            color: #888;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert.error {
            background: #fdecea;
            color: #800517;
            border: 1px solid #f5c6c2;
        }

        .alert.success {
            background: #eafaf1;
            color: #1e8449;
            border: 1px solid #a9dfbf;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
            animation: fadeUp 0.6s ease 0.4s both;
        }

        .form-group label {
            font-size: 13px;
            font-weight: 600;
            color: #333;
        }

        .input-wrap {
            position: relative;
        }

        .input-wrap .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 14px;
            color: #aaa;
            pointer-events: none;
        }

        .form-group input {
            width: 100%;
            padding: 14px 14px 14px 42px;
            border: 2px solid #e5e5e5;
            border-radius: 12px;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            color: #1a1a1a;
            background: #fff;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
            outline: none;
        }

        .form-group input:focus {
            border-color: #800517;
            box-shadow: 0 0 0 4px rgba(192, 57, 43, 0.1);
        }

        .form-group input::placeholder {
            color: #bbb;
        }

        .toggle-pw {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            font-size: 14px;
            color: #aaa;
            padding: 0;
            transition: color 0.2s ease;
        }

        .toggle-pw:hover { color: #800517; }

        .form-options {
            display: flex;
            align-items: center;
            justify-content: space-between;
            animation: fadeUp 0.6s ease 0.5s both;
        }

        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: #555;
            cursor: pointer;
        }

        .remember-me input[type="checkbox"] {
            accent-color: #800517;
            width: 15px;
            height: 15px;
            cursor: pointer;
        }

        .forgot-link {
            font-size: 13px;
            color: #800517;
            text-decoration: none;
            font-weight: 500;
        }

        .forgot-link:hover { text-decoration: underline; }

        .btn-login {
            width: 100%;
            padding: 16px;
            background: #800517;
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s ease, transform 0.15s ease, box-shadow 0.2s ease;
            box-shadow: 0 4px 20px rgba(192, 57, 43, 0.35);
            animation: fadeUp 0.6s ease 0.55s both;
            font-family: 'Inter', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-login:hover {
            background: #800517;
            transform: translateY(-2px);
            box-shadow: 0 8px 28px rgba(192, 57, 43, 0.45);
        }

        .btn-login:active { transform: translateY(0); }

        .register-link {
            text-align: center;
            font-size: 13px;
            color: #888;
            animation: fadeUp 0.6s ease 0.65s both;
        }

        .register-link a {
            color: #800517;
            font-weight: 600;
            text-decoration: none;
        }

        .register-link a:hover { text-decoration: underline; }

        @keyframes slideInLeft {
            from { transform: translateX(-40px); opacity: 0; }
            to   { transform: translateX(0);     opacity: 1; }
        }

        @keyframes slideInRight {
            from { transform: translateX(40px); opacity: 0; }
            to   { transform: translateX(0);    opacity: 1; }
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0);    }
        }
    </style>
</head>
<body>

<div class="left-panel">
    <div class="left-content">

        <div class="logo-wrap">
            <img src="assets/images/logo.png" alt="TimeSaver Logo">
            <span class="brand-name">TimeSaver</span>
        </div>

        <div class="left-tagline">
            Welcome back!
            <span>Log in to continue your Pomodoro sessions and stay on track.</span>
        </div>

        <div class="info-cards">
            <div class="info-card">
                <div class="ic-icon"><i class="fas fa-stopwatch"></i></div>
                <div class="ic-text">
                    Pomodoro Timer
                    <small>25-minute focus sessions with short breaks</small>
                </div>
            </div>
            <div class="info-card">
                <div class="ic-icon"><i class="fas fa-tasks"></i></div>
                <div class="ic-text">
                    Task Manager
                    <small>Add, track, and complete your study tasks</small>
                </div>
            </div>
            <div class="info-card">
                <div class="ic-icon"><i class="fas fa-chart-bar"></i></div>
                <div class="ic-text">
                    Progress Tracker
                    <small>View your weekly study session history</small>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="right-panel">
    <div class="form-box">

        <div class="form-header">
            <h1>Sign in to <span>TimeSaver</span></h1>
            <p>Enter your credentials to access your account.</p>
        </div>

        <?php if (isset($_GET['error'])): ?>
            <div class="alert error">
                <i class="fas fa-circle-exclamation"></i>
                <?php
                    $err = $_GET['error'];
                    if ($err === 'invalid')   echo 'Invalid email or password. Please try again.';
                    elseif ($err === 'empty') echo 'Please fill in all fields.';
                    else                      echo 'An error occurred. Please try again.';
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['registered'])): ?>
            <div class="alert success">
                <i class="fas fa-circle-check"></i>
                Account created successfully! Please log in.
            </div>
        <?php endif; ?>

        <form action="auth/login_process.php" method="POST">

            <div class="form-group">
                <label for="email">Email Address</label>
                <div class="input-wrap">
                    <i class="fas fa-envelope input-icon"></i>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        autocomplete="email"
                    >
                </div>
            </div>

            <br>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock input-icon"></i>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        required
                        autocomplete="current-password"
                    >
                    <button type="button" class="toggle-pw" onclick="togglePassword()">
                        <i class="fas fa-eye" id="toggleIcon"></i>
                    </button>
                </div>
            </div>

            <br>

            <div class="form-options">
                <label class="remember-me">
                    <input type="checkbox" name="remember"> Remember me
                </label>
                <a href="#" class="forgot-link">Forgot password?</a>
            </div>

            <br>

            <button type="submit" class="btn-login">
                <i class="fas fa-right-to-bracket"></i> Login
            </button>

        </form>

        <p class="register-link">
            Don't have an account? <a href="register.php">Register Now</a>
        </p>

    </div>
</div>

<script>
    function togglePassword() {
        const pw   = document.getElementById('password');
        const icon = document.getElementById('toggleIcon');
        if (pw.type === 'password') {
            pw.type = 'text';
            icon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            pw.type = 'password';
            icon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }
</script>

</body>
</html>