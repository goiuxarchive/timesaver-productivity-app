<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TimeSaver</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #800517;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            overflow: hidden;
        }

        .splash-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 24px;
            animation: fadeIn 0.8s ease forwards;
        }

        .logo-wrap {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .logo-wrap img {
            width: 150px;
            height: 200px;
            object-fit: contain;
        }

        .brand-name {
            font-size: 64px;
            font-weight: 900;
            color: #ffffff;
            letter-spacing: -2px;
            line-height: 1;
            animation: slideRight 0.7s cubic-bezier(0.34, 1.56, 0.64, 1) 0.2s both;
        }

        .tagline {
            font-size: 15px;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.7);
            letter-spacing: 3px;
            text-transform: uppercase;
            animation: fadeIn 0.8s ease 0.6s both;
        }

        .loader-bar {
            width: 180px;
            height: 3px;
            background: rgba(255,255,255,0.25);
            border-radius: 99px;
            overflow: hidden;
            animation: fadeIn 0.5s ease 0.8s both;
        }

        .loader-bar-fill {
            height: 100%;
            width: 0%;
            background: #ffffff;
            border-radius: 99px;
            animation: loadFill 1.8s ease 1s forwards;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to   { opacity: 1; }
        }

        @keyframes scaleIn {
            from { opacity: 0; transform: scale(0.5); }
            to   { opacity: 1; transform: scale(1); }
        }

        @keyframes slideRight {
            from { opacity: 0; transform: translateX(-30px); }
            to   { opacity: 1; transform: translateX(0); }
        }

        @keyframes loadFill {
            from { width: 0%; }
            to   { width: 100%; }
        }
    </style>
</head>
<body>

<div class="splash-container">
    <div class="logo-wrap">
        <img src="assets/images/logo.png" alt="TimeSaver Logo">
        <span class="brand-name">TimeSaver</span>
    </div>
    <p class="tagline">Study smarter, not harder</p>
    <div class="loader-bar">
        <div class="loader-bar-fill"></div>
    </div>
</div>

<script>
    setTimeout(function () {
        window.location.href = 'welcome.php';
    }, 3000);
</script>

</body>
</html>