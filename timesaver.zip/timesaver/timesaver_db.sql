CREATE DATABASE IF NOT EXISTS timesaver_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE timesaver_db;

CREATE TABLE IF NOT EXISTS users (
    id         INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(80)      NOT NULL,
    last_name  VARCHAR(80)      NOT NULL,
    email      VARCHAR(191)     NOT NULL,
    password   VARCHAR(255)     NOT NULL,
    created_at DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS remember_tokens (
    id         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    user_id    INT UNSIGNED  NOT NULL,
    token      VARCHAR(64)   NOT NULL,
    expires_at DATETIME      NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_token (token),
    CONSTRAINT fk_rt_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tasks (
    id          INT UNSIGNED                            NOT NULL AUTO_INCREMENT,
    user_id     INT UNSIGNED                            NOT NULL,
    title       VARCHAR(255)                            NOT NULL,
    description TEXT                                    NULL,
    subject     VARCHAR(100)                            NULL,
    priority    ENUM('low','medium','high')             NOT NULL DEFAULT 'medium',
    status      ENUM('pending','in_progress','done')    NOT NULL DEFAULT 'pending',
    due_date    DATE                                    NULL,
    created_at  DATETIME                                NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_tasks_user (user_id),
    CONSTRAINT fk_tasks_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS sessions (
    id           INT UNSIGNED                                    NOT NULL AUTO_INCREMENT,
    user_id      INT UNSIGNED                                    NOT NULL,
    task_id      INT UNSIGNED                                    NULL,
    session_type ENUM('pomodoro','short_break','long_break')     NOT NULL DEFAULT 'pomodoro',
    duration     SMALLINT UNSIGNED                               NOT NULL DEFAULT 25,
    started_at   DATETIME                                        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_sessions_user    (user_id),
    KEY idx_sessions_task    (task_id),
    KEY idx_sessions_started (started_at),
    CONSTRAINT fk_sessions_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_sessions_task FOREIGN KEY (task_id)
        REFERENCES tasks (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
