<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            min-height: 100vh;
            background-color: #f0f2f5;
            display: flex;
            overflow: hidden;
        }

        .left-panel {
            width: 55%;
            background-color: #800517;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px;
            position: relative;
            overflow: hidden;
            animation: slideInLeft 0.7s cubic-bezier(0.34, 1.2, 0.64, 1) forwards;
        }

        .left-panel::before {
            content: '';
            position: absolute;
            width: 420px;
            height: 420px;
            border-radius: 50%;
            border: 60px solid rgba(255,255,255,0.07);
            top: -120px;
            left: -120px;
        }

        .left-panel::after {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            border: 50px solid rgba(255,255,255,0.07);
            bottom: -80px;
            right: -80px;
        }

        .left-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 28px;
            z-index: 1;
            text-align: center;
        }

        .logo-wrap {
            display: flex;
            align-items: center;
            gap: 16px;
            animation: fadeUp 0.6s ease 0.3s both;
        }

        .logo-wrap img {
            width: 80px;
            height: 80px;
            object-fit: contain;
            filter: brightness(0) invert(1);
        }

        .brand-name {
            font-size: 52px;
            font-weight: 900;
            color: #ffffff;
            letter-spacing: -2px;
            line-height: 1;
        }

        .welcome-heading {
            font-size: 32px;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.2;
            animation: fadeUp 0.6s ease 0.45s both;
        }

        .welcome-heading span {
            display: block;
            font-size: 18px;
            font-weight: 400;
            color: rgba(255,255,255,0.75);
            margin-top: 10px;
            letter-spacing: 0.3px;
        }

        .features {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 14px;
            width: 100%;
            max-width: 340px;
            animation: fadeUp 0.6s ease 0.6s both;
        }

        .features li {
            display: flex;
            align-items: center;
            gap: 12px;
            background: rgba(255,255,255,0.12);
            border-radius: 12px;
            padding: 12px 16px;
            color: #ffffff;
            font-size: 14px;
            font-weight: 500;
        }

        .features li .icon {
            font-size: 20px;
            flex-shrink: 0;
        }

        .right-panel {
            width: 45%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px 50px;
            animation: slideInRight 0.7s cubic-bezier(0.34, 1.2, 0.64, 1) forwards;
        }

        .right-content {
            width: 100%;
            max-width: 360px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 32px;
        }

        .right-heading {
            font-size: 28px;
            font-weight: 800;
            color: #1a1a1a;
            text-align: center;
            line-height: 1.3;
            animation: fadeUp 0.6s ease 0.5s both;
        }

        .right-heading span {
            color: #800517;
        }

        .right-sub {
            font-size: 14px;
            color: #666;
            text-align: center;
            line-height: 1.6;
            margin-top: -16px;
            animation: fadeUp 0.6s ease 0.6s both;
        }

        .btn-group {
            display: flex;
            flex-direction: column;
            gap: 14px;
            width: 100%;
            animation: fadeUp 0.6s ease 0.7s both;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 16px;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 700;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            border: none;
            transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .btn-primary {
            background: #800517;
            color: #ffffff;
            box-shadow: 0 4px 20px rgba(192, 57, 43, 0.35);
        }

        .btn-primary:hover {
            background: #800517;
            box-shadow: 0 8px 28px rgba(192, 57, 43, 0.45);
        }

        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 2px solid #e5e5e5;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }

        .btn-secondary:hover {
            border-color: #800517;
            color: #800517;
            box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        }

        .divider {
            display: flex;
            align-items: center;
            gap: 12px;
            width: 100%;
            animation: fadeUp 0.6s ease 0.75s both;
        }

        .divider hr {
            flex: 1;
            border: none;
            border-top: 1px solid #e0e0e0;
        }

        .divider span {
            font-size: 12px;
            color: #aaa;
            font-weight: 500;
        }

        .footer-note {
            font-size: 13px;
            color: #999;
            text-align: center;
            animation: fadeUp 0.6s ease 0.85s both;
        }

        .steps {
            display: flex;
            gap: 10px;
            width: 100%;
            animation: fadeUp 0.6s ease 0.65s both;
        }

        .step {
            flex: 1;
            background: #fff8f7;
            border: 1px solid #fdd;
            border-radius: 10px;
            padding: 12px 8px;
            text-align: center;
        }

        .step .step-num {
            display: inline-block;
            width: 24px;
            height: 24px;
            background: #800517;
            color: #fff;
            border-radius: 50%;
            font-size: 12px;
            font-weight: 700;
            line-height: 24px;
            margin-bottom: 6px;
        }

        .step p {
            font-size: 11px;
            color: #555;
            font-weight: 500;
            line-height: 1.4;
        }

        @keyframes slideInLeft {
            from { transform: translateX(-40px); opacity: 0; }
            to   { transform: translateX(0);     opacity: 1; }
        }

        @keyframes slideInRight {
            from { transform: translateX(40px); opacity: 0; }
            to   { transform: translateX(0);    opacity: 1; }
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0);    }
        }
    </style>
</head>
<body>

<div class="left-panel">
    <div class="left-content">

        <div class="logo-wrap">
            <img src="assets/images/logo.png" alt="TimeSaver Logo">
            <span class="brand-name">TimeSaver</span>
        </div>

        <div class="welcome-heading">
            Your personal study<br>time manager.
        </div>

        <ul class="features">
            <li><span class="icon"></span> 25-minute focused study sessions</li>
            <li><span class="icon"></span> Short breaks to recharge</li>
            <li><span class="icon"></span> Task manager to stay on track</li>
            <li><span class="icon"></span> Weekly progress tracking</li>
        </ul>

    </div>
</div>

<div class="right-panel">
    <div class="right-content">

        <div class="right-heading">
            Welcome to <span>TimeSaver!</span>
        </div>

        <p class="right-sub">
            Study smarter, not harder. Start your first Pomodoro session today.
        </p>

        <div class="steps">
            <div class="step">
                <div class="step-num">1</div>
                <p>Add your tasks</p>
            </div>
            <div class="step">
                <div class="step-num">2</div>
                <p>Start the timer</p>
            </div>
            <div class="step">
                <div class="step-num">3</div>
                <p>Take a break</p>
            </div>
            <div class="step">
                <div class="step-num">4</div>
                <p>Track progress</p>
            </div>
        </div>

        <div class="btn-group">
            <a href="login.php" class="btn btn-primary">Login</a>
            <a href="register.php" class="btn btn-secondary">Create an Account</a>
        </div>

        <div class="divider">
            <hr><span><strong>What is Pomodoro?</strong></span><hr>
        </div>

        <p class="footer-note">
            The Pomodoro Technique breaks study into 25-min focus intervals followed by 5-min breaks — helping you stay sharp and avoid burnout.
        </p>

    </div>
</div>

</body>
</html>