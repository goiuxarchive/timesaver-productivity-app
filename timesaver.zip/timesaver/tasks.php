<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
include 'config/db.php';
include 'csrf_helper.php';

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT * FROM tasks
    WHERE user_id = :uid
    ORDER BY
        FIELD(status, 'in_progress', 'pending', 'done'),
        due_date IS NULL ASC,
        due_date ASC
");
$stmt->execute([':uid' => $user_id]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total      = count($tasks);
$pending    = count(array_filter($tasks, fn($t) => $t['status'] === 'pending'));
$inProgress = count(array_filter($tasks, fn($t) => $t['status'] === 'in_progress'));
$done       = count(array_filter($tasks, fn($t) => $t['status'] === 'done'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="inner-page">

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <div class="tasks-page">

        <div class="page-header">
            <div class="page-header-left">
                <div class="page-eyebrow"><i class="fas fa-bolt"></i>Study Hub</div>
                <h1 class="page-title">MY TASKS</h1>
                <p class="page-subtitle">Stay on top of your study game!</p>
            </div>
            <button class="btn-add-task" onclick="openModal()">
                <span class="btn-add-inner">
                    <i class="fas fa-plus"></i>
                    <span>Add Task</span>
                </span>
            </button>
        </div>

        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                <div class="alert-icon"><i class="fas fa-circle-check"></i></div>
                <span><?php
                    $s = $_GET['success'];
                    if ($s === 'added')        echo 'Task added successfully!';
                    elseif ($s === 'updated')  echo 'Task updated successfully!';
                    elseif ($s === 'deleted')  echo 'Task deleted.';
                ?></span>
                <button class="alert-close" onclick="this.parentElement.remove()"><i class="fas fa-xmark"></i></button>
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <div class="alert-icon"><i class="fas fa-circle-exclamation"></i></div>
                <span>Something went wrong. Please try again.</span>
                <button class="alert-close" onclick="this.parentElement.remove()"><i class="fas fa-xmark"></i></button>
            </div>
        <?php endif; ?>

        <div class="task-stats">
            <div class="task-stat-card stat-all">
                <div class="stat-bg-icon"><i class="fas fa-layer-group"></i></div>
                <div class="stat-content">
                    <span class="stat-val"><?= $total ?></span>
                    <span class="stat-label">Total Tasks</span>
                </div>
                <div class="stat-icon-wrap"><i class="fas fa-layer-group"></i></div>
            </div>
            <div class="task-stat-card stat-pending">
                <div class="stat-bg-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-content">
                    <span class="stat-val"><?= $pending ?></span>
                    <span class="stat-label">Pending</span>
                </div>
                <div class="stat-icon-wrap"><i class="fas fa-clock"></i></div>
            </div>
            <div class="task-stat-card stat-progress">
                <div class="stat-bg-icon"><i class="fas fa-fire"></i></div>
                <div class="stat-content">
                    <span class="stat-val"><?= $inProgress ?></span>
                    <span class="stat-label">In Progress</span>
                </div>
                <div class="stat-icon-wrap"><i class="fas fa-fire"></i></div>
            </div>
            <div class="task-stat-card stat-done">
                <div class="stat-bg-icon"><i class="fas fa-circle-check"></i></div>
                <div class="stat-content">
                    <span class="stat-val"><?= $done ?></span>
                    <span class="stat-label">Completed</span>
                </div>
                <div class="stat-icon-wrap"><i class="fas fa-circle-check"></i></div>
            </div>
        </div>

        <div class="task-toolbar">
            <div class="search-wrap">
                <i class="fas fa-magnifying-glass"></i>
                <input type="text" id="searchInput" placeholder="Search your tasks..." oninput="filterTasks()">
            </div>
            <div class="filter-tabs">
                <button class="filter-tab active" data-filter="all"          onclick="setFilter('all', this)">All</button>
                <button class="filter-tab"         data-filter="pending"     onclick="setFilter('pending', this)">Pending</button>
                <button class="filter-tab"         data-filter="in_progress" onclick="setFilter('in_progress', this)">In Progress</button>
                <button class="filter-tab"         data-filter="done"        onclick="setFilter('done', this)">Done</button>
            </div>
        </div>

        <div class="table-wrap">
            <?php if (empty($tasks)): ?>
                <div class="empty-state">
                    <div class="empty-blob"></div>
                    <div class="empty-icon"><i class="fas fa-list-check"></i></div>
                    <h3>No tasks yet!</h3>
                    <p>Add your first study task and start crushing it!</p>
                    <button class="btn-add-task" onclick="openModal()">
                        <span class="btn-add-inner"><i class="fas fa-plus"></i><span>Add Task</span></span>
                    </button>
                </div>
            <?php else: ?>
            <table class="tasks-table" id="tasksTable">
                <thead>
                    <tr>
                        <th style="width:44px">#</th>
                        <th>Task</th>
                        <th>Subject</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Due Date</th>
                        <th style="width:100px">Actions</th>
                    </tr>
                </thead>
                <tbody id="taskTableBody">
                    <?php foreach ($tasks as $i => $task):
                        $prio      = $task['priority'] ?? 'medium';
                        $status    = $task['status'];
                        $isDone    = $status === 'done';
                        $isOverdue = false;
                        if (!empty($task['due_date']) && !$isDone) {
                            $isOverdue = (new DateTime($task['due_date'])) < new DateTime();
                        }
                    ?>
                    <tr
                        class="task-row <?= $isDone ? 'row-done' : '' ?> <?= $isOverdue ? 'row-overdue' : '' ?> prio-row-<?= $prio ?>"
                        data-status="<?= htmlspecialchars($status) ?>"
                        data-name="<?= strtolower(htmlspecialchars($task['title'])) ?>"
                        style="animation-delay: <?= $i * 0.04 ?>s"
                    >
                        <td class="td-num"><?= $i + 1 ?></td>
                        <td class="td-title">
                            <div class="task-title-wrap">
                                <span class="task-title <?= $isDone ? 'task-done-text' : '' ?>">
                                    <?= htmlspecialchars($task['title']) ?>
                                </span>
                                <?php if (!empty($task['description'])): ?>
                                    <span class="task-desc"><?= htmlspecialchars($task['description']) ?></span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php if (!empty($task['subject'])): ?>
                                <span class="subject-chip"><?= htmlspecialchars($task['subject']) ?></span>
                            <?php else: ?>
                                <span class="td-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                                $prioClass = ['high'=>'prio-high','medium'=>'prio-medium','low'=>'prio-low'][$prio] ?? 'prio-medium';
                                $prioIcon  = ['high'=>'fa-angles-up','medium'=>'fa-equals','low'=>'fa-angles-down'][$prio] ?? 'fa-equals';
                            ?>
                            <span class="prio-badge <?= $prioClass ?>">
                                <i class="fas <?= $prioIcon ?>"></i><?= ucfirst($prio) ?>
                            </span>
                        </td>
                        <td>
                            <?php
                                $statusClass = ['pending'=>'status-pending','in_progress'=>'status-progress','done'=>'status-done'][$status] ?? 'status-pending';
                                $statusLabel = ['pending'=>'Pending','in_progress'=>'In Progress','done'=>'Done'][$status] ?? 'Pending';
                            ?>
                            <span class="status-badge <?= $statusClass ?>"><?= $statusLabel ?></span>
                        </td>
                        <td class="td-date">
                            <?php if (!empty($task['due_date'])): ?>
                                <span class="<?= $isOverdue ? 'date-overdue' : 'date-normal' ?>">
                                    <?php if ($isOverdue): ?><i class="fas fa-triangle-exclamation"></i><?php endif; ?>
                                    <?= (new DateTime($task['due_date']))->format('M d, Y') ?>
                                </span>
                            <?php else: ?>
                                <span class="td-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="action-btns">
                                <button class="act-btn act-btn--edit" title="Edit"
                                    onclick='openEditModal(
                                        <?= $task["id"] ?>,
                                        <?= json_encode($task["title"]) ?>,
                                        <?= json_encode($task["description"] ?? "") ?>,
                                        <?= json_encode($task["subject"] ?? "") ?>,
                                        <?= json_encode($task["priority"] ?? "medium") ?>,
                                        <?= json_encode($task["status"]) ?>,
                                        <?= json_encode($task["due_date"] ?? "") ?>
                                    )'>
                                    <i class="fas fa-pen"></i>
                                </button>
                                <button class="act-btn act-btn--delete" title="Delete"
                                    onclick='confirmDelete(<?= $task["id"] ?>, <?= json_encode($task["title"]) ?>)'>
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="no-results" id="noResults" style="display:none;">
                <i class="fas fa-magnifying-glass"></i>
                <p>No tasks match your search.</p>
            </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<div class="modal-overlay" id="taskModal">
    <div class="modal-card">
        <div class="modal-header">
            <div class="modal-header-icon"><i class="fas fa-list-check" id="modalHeaderIcon"></i></div>
            <div>
                <h2 class="modal-title" id="modalTitle">Add New Task</h2>
                <p class="modal-sub">Fill in the details for your task.</p>
            </div>
            <button class="modal-x" onclick="closeModal()"><i class="fas fa-xmark"></i></button>
        </div>
        <form action="tasks_process.php" method="POST" id="taskForm">
            <?= csrf_field() ?>
            <input type="hidden" name="action"  id="formAction"  value="add">
            <input type="hidden" name="task_id" id="formTaskId"  value="">
            <div class="modal-body">
                <div class="form-group">
                    <label for="taskTitle">Task Title <span class="req">*</span></label>
                    <div class="input-wrap">
                        <i class="fas fa-pen input-icon"></i>
                        <input type="text" id="taskTitle" name="title" placeholder="e.g. Review Chapter 5" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="taskDesc">Description <span class="opt">(optional)</span></label>
                    <textarea id="taskDesc" name="description" placeholder="Add notes or details..." rows="3"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="taskSubject">Subject</label>
                        <div class="input-wrap">
                            <i class="fas fa-book input-icon"></i>
                            <input type="text" id="taskSubject" name="subject" placeholder="e.g. Math">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="taskPriority">Priority</label>
                        <div class="select-wrap">
                            <i class="fas fa-flag input-icon"></i>
                            <select id="taskPriority" name="priority">
                                <option value="low">Low</option>
                                <option value="medium" selected>Medium</option>
                                <option value="high">High</option>
                            </select>
                            <i class="fas fa-chevron-down select-arrow"></i>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="taskStatus">Status</label>
                        <div class="select-wrap">
                            <i class="fas fa-circle-half-stroke input-icon"></i>
                            <select id="taskStatus" name="status">
                                <option value="pending" selected>Pending</option>
                                <option value="in_progress">In Progress</option>
                                <option value="done">Done</option>
                            </select>
                            <i class="fas fa-chevron-down select-arrow"></i>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="taskDue">Due Date</label>
                        <div class="input-wrap">
                            <i class="fas fa-calendar input-icon"></i>
                            <input type="date" id="taskDue" name="due_date">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn--cancel" onclick="closeModal()">Cancel</button>
                <button type="submit" class="modal-btn modal-btn--submit" id="submitBtn">
                    <i class="fas fa-plus" id="submitIcon"></i>
                    <span id="submitLabel">Add Task</span>
                </button>
            </div>
        </form>
    </div>
</div>

<div class="modal-overlay" id="deleteModal">
    <div class="modal-card modal-card--sm">
        <div class="delete-icon"><i class="fas fa-trash"></i></div>
        <h2 class="modal-title" style="text-align:center;">Delete Task?</h2>
        <p class="delete-msg">Are you sure you want to delete <strong id="deleteTaskName"></strong>? This cannot be undone.</p>
        <div class="modal-footer" style="margin-top:8px;">
            <button class="modal-btn modal-btn--cancel" onclick="closeDeleteModal()">Cancel</button>
            <form action="tasks_process.php" method="POST" style="flex:1;">
                <input type="hidden" name="action"  value="delete">
                <input type="hidden" name="task_id" id="deleteTaskId">
                <?= csrf_field() ?>
                <button type="submit" class="modal-btn modal-btn--delete" style="width:100%;">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </form>
        </div>
    </div>
</div>

<style>
.tasks-page {
    padding: 36px 40px 60px;
    max-width: 1140px;
    margin: 0 auto;
    width: 100%;
}

/* ── Page Header ── */
.page-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 28px;
    gap: 16px;
    flex-wrap: wrap;
}

.page-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #c0392b;
    background: rgba(192,57,43,0.08);
    padding: 4px 12px;
    border-radius: 99px;
    margin-bottom: 10px;
}

.page-title {
    font-family: 'Inter', sans-serif;
    font-size: 36px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -1.5px;
    line-height: 1;
    margin-bottom: 6px;
}

.page-subtitle {
    font-size: 15px;
    color: #999;
    font-weight: 400;
}

/* ── Add Task Button ── */
.btn-add-task {
    background: linear-gradient(135deg, #c0392b 0%, #e74c3c 100%);
    border: none;
    border-radius: 16px;
    padding: 3px;
    cursor: pointer;
    box-shadow: 0 8px 24px rgba(192,57,43,0.35), 0 2px 8px rgba(192,57,43,0.2);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    position: relative;
    overflow: hidden;
}

.btn-add-task::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.15) 0%, transparent 60%);
    border-radius: inherit;
}

.btn-add-task:hover {
    transform: translateY(-3px) scale(1.02);
    box-shadow: 0 16px 40px rgba(192,57,43,0.45), 0 4px 12px rgba(192,57,43,0.3);
}

.btn-add-task:active { transform: translateY(-1px) scale(1); }

.btn-add-inner {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 22px;
    font-size: 14px;
    font-weight: 700;
    color: #fff;
    font-family: 'Inter', sans-serif;
    letter-spacing: 0.3px;
}

.alert {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 18px;
    border-radius: 14px;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 24px;
    animation: slideDown 0.4s cubic-bezier(0.34,1.56,0.64,1) both;
}

.alert-icon {
    width: 32px;
    height: 32px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    flex-shrink: 0;
}

.alert-success { background: #eafaf1; color: #1e8449; border: 1px solid #a9dfbf; }
.alert-success .alert-icon { background: rgba(39,174,96,0.15); color: #1e8449; }
.alert-error   { background: #fdecea; color: #800517; border: 1px solid #f5c6c2; }
.alert-error   .alert-icon { background: rgba(192,57,43,0.15); color: #800517; }

.alert-close {
    margin-left: auto;
    background: none;
    border: none;
    cursor: pointer;
    color: inherit;
    opacity: 0.5;
    font-size: 14px;
    padding: 4px;
    border-radius: 6px;
    transition: opacity 0.2s;
}

.alert-close:hover { opacity: 1; }

.task-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 28px;
}

.task-stat-card {
    border-radius: 20px;
    padding: 22px 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    position: relative;
    overflow: hidden;
    cursor: default;
    transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1),
                box-shadow 0.25s ease;
    animation: cardPop 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
}

.task-stat-card:nth-child(1) { animation-delay: 0.05s; }
.task-stat-card:nth-child(2) { animation-delay: 0.10s; }
.task-stat-card:nth-child(3) { animation-delay: 0.15s; }
.task-stat-card:nth-child(4) { animation-delay: 0.20s; }

.task-stat-card:hover {
    transform: translateY(-6px) scale(1.02);
}

.stat-all {
    background: linear-gradient(135deg, #1a1a2e 0%, #2d2d44 100%);
    box-shadow: 0 8px 32px rgba(26,26,46,0.25);
}
.stat-all:hover { box-shadow: 0 16px 48px rgba(26,26,46,0.35); }

.stat-pending {
    background: linear-gradient(135deg, #d68910 0%, #f39c12 100%);
    box-shadow: 0 8px 32px rgba(214,137,16,0.3);
}
.stat-pending:hover { box-shadow: 0 16px 48px rgba(214,137,16,0.45); }

.stat-progress {
    background: linear-gradient(135deg, #c0392b 0%, #e74c3c 100%);
    box-shadow: 0 8px 32px rgba(192,57,43,0.3);
}
.stat-progress:hover { box-shadow: 0 16px 48px rgba(192,57,43,0.45); }

.stat-done {
    background: linear-gradient(135deg, #1e8449 0%, #27ae60 100%);
    box-shadow: 0 8px 32px rgba(30,132,73,0.3);
}
.stat-done:hover { box-shadow: 0 16px 48px rgba(30,132,73,0.45); }

.stat-bg-icon {
    position: absolute;
    right: -10px;
    bottom: -10px;
    font-size: 72px;
    color: rgba(255,255,255,0.08);
    pointer-events: none;
    line-height: 1;
}

.stat-content {
    display: flex;
    flex-direction: column;
    gap: 4px;
    z-index: 1;
}

.stat-val {
    font-family: 'Syne', sans-serif;
    font-size: 38px;
    font-weight: 800;
    color: #fff;
    line-height: 1;
    letter-spacing: -2px;
}

.stat-label {
    font-size: 12px;
    font-weight: 600;
    color: rgba(255,255,255,0.65);
    letter-spacing: 0.5px;
    text-transform: uppercase;
}

.stat-icon-wrap {
    margin-left: auto;
    width: 44px;
    height: 44px;
    border-radius: 14px;
    background: rgba(255,255,255,0.15);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    color: rgba(255,255,255,0.9);
    backdrop-filter: blur(4px);
    flex-shrink: 0;
    z-index: 1;
}

.task-toolbar {
    display: flex;
    align-items: center;
    gap: 14px;
    margin-bottom: 18px;
    flex-wrap: wrap;
}

.search-wrap {
    position: relative;
    flex: 1;
    min-width: 200px;
}

.search-wrap i {
    position: absolute;
    left: 16px;
    top: 50%;
    transform: translateY(-50%);
    color: #bbb;
    font-size: 13px;
    pointer-events: none;
}

.search-wrap input {
    width: 100%;
    padding: 13px 16px 13px 42px;
    border: 2px solid #efefef;
    border-radius: 14px;
    font-size: 14px;
    font-family: 'Inter', sans-serif;
    color: #1a1a1a;
    background: #fff;
    outline: none;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.search-wrap input:focus {
    border-color: #c0392b;
    box-shadow: 0 0 0 4px rgba(192,57,43,0.08), 0 2px 8px rgba(0,0,0,0.04);
}

.search-wrap input::placeholder { color: #ccc; }

.filter-tabs {
    display: flex;
    background: #fff;
    border: 2px solid #efefef;
    border-radius: 14px;
    padding: 5px;
    gap: 4px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.filter-tab {
    padding: 9px 18px;
    border-radius: 10px;
    border: none;
    background: none;
    font-size: 13px;
    font-weight: 700;
    color: #bbb;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
    transition: all 0.2s ease;
    white-space: nowrap;
}

.filter-tab:hover { color: #555; background: #f7f7f7; }

.filter-tab.active {
    background: linear-gradient(135deg, #c0392b, #e74c3c);
    color: #fff;
    box-shadow: 0 4px 12px rgba(192,57,43,0.35);
}

.table-wrap {
    background: #fff;
    border-radius: 22px;
    border: 2px solid #f0f0f0;
    box-shadow: 0 4px 24px rgba(0,0,0,0.06);
    overflow: hidden;
}

.table-wrap::-webkit-scrollbar { height: 6px; }
.table-wrap::-webkit-scrollbar-track { background: #f5f5f5; }
.table-wrap::-webkit-scrollbar-thumb { background: #c0392b; border-radius: 99px; }

.tasks-table {
    width: 100%;
    border-collapse: collapse;
}

.tasks-table thead tr {
    background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
    position: sticky;
    top: 0;
    z-index: 10;
}

.tasks-table th {
    padding: 15px 18px;
    font-size: 11px;
    font-weight: 700;
    color: rgba(255,255,255,0.5);
    text-transform: uppercase;
    letter-spacing: 1px;
    text-align: left;
    white-space: nowrap;
}

.tasks-table td {
    padding: 16px 18px;
    font-size: 13px;
    color: #333;
    border-bottom: 1px solid #f5f5f5;
    vertical-align: middle;
}

.task-row {
    transition: background 0.15s ease, transform 0.15s ease;
    animation: rowSlideIn 0.4s ease both;
    position: relative;
}

.task-row:last-child td { border-bottom: none; }

.task-row:hover {
    background: #fafafa;
}

.prio-row-high   td:first-child { border-left: 4px solid #c0392b; }
.prio-row-medium td:first-child { border-left: 4px solid #f39c12; }
.prio-row-low    td:first-child { border-left: 4px solid #27ae60; }

.row-done { background: rgba(39,174,96,0.03); }
.row-done:hover { background: rgba(39,174,96,0.06); }

.row-overdue { background: rgba(192,57,43,0.03); }
.row-overdue:hover { background: rgba(192,57,43,0.06); }

.td-num {
    color: #ddd;
    font-family: 'Space Mono', monospace;
    font-size: 12px;
    text-align: center;
    padding-left: 20px;
}

.td-title { max-width: 240px; }

.task-title-wrap {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.task-title {
    font-size: 14px;
    font-weight: 700;
    color: #1a1a1a;
    line-height: 1.3;
}

.task-done-text {
    text-decoration: line-through;
    color: #bbb;
    font-weight: 500;
}

.task-desc {
    font-size: 12px;
    color: #bbb;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 220px;
}

.subject-chip {
    display: inline-block;
    padding: 4px 12px;
    background: #f5f5f5;
    color: #555;
    border-radius: 99px;
    font-size: 12px;
    font-weight: 700;
    white-space: nowrap;
    border: 1px solid #ebebeb;
}

.td-muted { color: #ddd; font-size: 13px; }

.prio-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 12px;
    border-radius: 99px;
    font-size: 11px;
    font-weight: 800;
    white-space: nowrap;
    letter-spacing: 0.3px;
    text-transform: uppercase;
}

.prio-high   { background: rgba(192,57,43,0.1);  color: #800517; border: 1px solid rgba(192,57,43,0.2); }
.prio-medium { background: rgba(243,156,18,0.1);  color: #b7770d; border: 1px solid rgba(243,156,18,0.2); }
.prio-low    { background: rgba(39,174,96,0.1);   color: #1e8449; border: 1px solid rgba(39,174,96,0.2); }

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 14px;
    border-radius: 99px;
    font-size: 12px;
    font-weight: 700;
    white-space: nowrap;
}

.status-badge::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: 50%;
    flex-shrink: 0;
}

.status-pending  { background: rgba(243,156,18,0.1); color: #b7770d; border: 1px solid rgba(243,156,18,0.2); }
.status-pending::before  { background: #f39c12; }
.status-progress { background: rgba(52,152,219,0.1); color: #1a6fa6; border: 1px solid rgba(52,152,219,0.2); }
.status-progress::before { background: #3498db; }
.status-done     { background: rgba(39,174,96,0.1);  color: #1e8449; border: 1px solid rgba(39,174,96,0.2); }
.status-done::before     { background: #27ae60; }

.date-normal  { font-size: 13px; color: #888; font-weight: 500; }
.date-overdue {
    font-size: 13px;
    color: #c0392b;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: rgba(192,57,43,0.08);
    padding: 3px 10px;
    border-radius: 99px;
}

.action-btns { display: flex; gap: 6px; }

.act-btn {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    border: 2px solid #f0f0f0;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-size: 12px;
    background: #fff;
    transition: all 0.2s cubic-bezier(0.34,1.56,0.64,1);
    color: #ccc;
}

.act-btn--edit:hover {
    border-color: #c0392b;
    color: #c0392b;
    background: rgba(192,57,43,0.06);
    transform: scale(1.15);
}

.act-btn--delete:hover {
    border-color: #c0392b;
    color: #c0392b;
    background: rgba(192,57,43,0.06);
    transform: scale(1.15);
}

.no-results {
    padding: 40px;
    text-align: center;
    color: #ccc;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    font-size: 14px;
}

.no-results i { font-size: 32px; color: #e0e0e0; }

.empty-state {
    padding: 80px 20px;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 14px;
    position: relative;
    overflow: hidden;
}

.empty-blob {
    position: absolute;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(192,57,43,0.06) 0%, transparent 70%);
    border-radius: 50%;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    pointer-events: none;
}

.empty-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, rgba(192,57,43,0.1), rgba(231,76,60,0.15));
    border-radius: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 32px;
    color: #c0392b;
    margin-bottom: 4px;
    border: 2px solid rgba(192,57,43,0.1);
}

.empty-state h3 {
    font-family: 'Syne', sans-serif;
    font-size: 22px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -0.5px;
}

.empty-state p { font-size: 14px; color: #aaa; }

.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(6px);
    z-index: 500;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-overlay.open {
    display: flex;
    animation: fadeIn 0.2s ease both;
}

.modal-card {
    background: #fff;
    border-radius: 24px;
    width: 100%;
    max-width: 520px;
    box-shadow: 0 40px 100px rgba(0,0,0,0.25);
    overflow: hidden;
    animation: modalPop 0.35s cubic-bezier(0.34,1.56,0.64,1) both;
}

.modal-card--sm {
    max-width: 380px;
    padding: 36px;
    text-align: center;
}

.modal-header {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 22px 24px;
    border-bottom: 1px solid #f5f5f5;
    background: #fafafa;
}

.modal-header-icon {
    width: 44px;
    height: 44px;
    background: linear-gradient(135deg, rgba(192,57,43,0.12), rgba(231,76,60,0.15));
    border-radius: 13px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #c0392b;
    font-size: 17px;
    flex-shrink: 0;
    border: 1px solid rgba(192,57,43,0.12);
}

.modal-title {
    font-family: 'Syne', sans-serif;
    font-size: 18px;
    font-weight: 800;
    color: #1a1a1a;
    letter-spacing: -0.3px;
}

.modal-sub {
    font-size: 13px;
    color: #bbb;
    margin-top: 2px;
}

.modal-x {
    margin-left: auto;
    background: #f0f0f0;
    border: none;
    color: #999;
    font-size: 14px;
    cursor: pointer;
    padding: 8px;
    border-radius: 10px;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    flex-shrink: 0;
}

.modal-x:hover { background: #e5e5e5; color: #333; }

.modal-body {
    padding: 22px 24px;
    display: flex;
    flex-direction: column;
    gap: 14px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.form-group label {
    font-size: 13px;
    font-weight: 700;
    color: #444;
    display: flex;
    align-items: center;
    gap: 6px;
}

.req { color: #c0392b; }
.opt { font-size: 11px; color: #ccc; font-weight: 400; }

.input-wrap { position: relative; }

.input-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #ccc;
    font-size: 13px;
    pointer-events: none;
}

.form-group input,
.form-group textarea {
    width: 80%;
    padding: 12px 14px 12px 40px;
    border: 2px solid #f0f0f0;
    border-radius: 12px;
    font-size: 14px;
    font-family: 'Inter', sans-serif;
    color: #1a1a1a;
    background: #fafafa;
    outline: none;
    transition: border-color 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
}

.form-group textarea {
    padding: 12px 14px;
    resize: vertical;
    min-height: 80px;
}

.form-group input:focus,
.form-group textarea:focus {
    border-color: #c0392b;
    background: #fff;
    box-shadow: 0 0 0 4px rgba(192,57,43,0.08);
}

.form-group input::placeholder,
.form-group textarea::placeholder { color: #ccc; }

.select-wrap { position: relative; }

.select-wrap select {
    width: 100%;
    padding: 12px 40px 12px 40px;
    border: 2px solid #f0f0f0;
    border-radius: 12px;
    font-size: 14px;
    font-family: 'Inter', sans-serif;
    color: #1a1a1a;
    background: #fafafa;
    outline: none;
    appearance: none;
    cursor: pointer;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.select-wrap select:focus {
    border-color: #c0392b;
    background: #fff;
    box-shadow: 0 0 0 4px rgba(192,57,43,0.08);
}

.select-arrow {
    position: absolute;
    right: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #ccc;
    font-size: 11px;
    pointer-events: none;
}

.form-row {
    display: flex;
    gap: 14px;
}

.form-row .form-group { flex: 1; }

.modal-footer {
    display: flex;
    gap: 10px;
    padding: 16px 24px;
    border-top: 1px solid #f5f5f5;
    background: #fafafa;
}

.modal-btn {
    flex: 1;
    padding: 13px;
    border-radius: 12px;
    border: none;
    font-size: 14px;
    font-weight: 700;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.2s ease;
}

.modal-btn--cancel {
    background: #f0f0f0;
    color: #888;
}

.modal-btn--cancel:hover { background: #e8e8e8; color: #555; }

.modal-btn--submit {
    background: linear-gradient(135deg, #c0392b, #e74c3c);
    color: #fff;
    box-shadow: 0 6px 20px rgba(192,57,43,0.35);
}

.modal-btn--submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 28px rgba(192,57,43,0.45);
}

.modal-btn--delete {
    background: linear-gradient(135deg, #c0392b, #e74c3c);
    color: #fff;
    box-shadow: 0 4px 14px rgba(192,57,43,0.3);
}

.modal-btn--delete:hover { transform: translateY(-1px); }

.delete-icon {
    width: 64px;
    height: 64px;
    background: linear-gradient(135deg, rgba(192,57,43,0.1), rgba(231,76,60,0.15));
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: #c0392b;
    margin: 0 auto 16px;
    border: 2px solid rgba(192,57,43,0.1);
}

.delete-msg {
    font-size: 14px;
    color: #999;
    line-height: 1.7;
    margin-top: 8px;
}

@keyframes cardPop {
    from { opacity: 0; transform: translateY(20px) scale(0.95); }
    to   { opacity: 1; transform: translateY(0)    scale(1);    }
}

@keyframes rowSlideIn {
    from { opacity: 0; transform: translateX(-12px); }
    to   { opacity: 1; transform: translateX(0); }
}

@keyframes slideDown {
    from { opacity: 0; transform: translateY(-12px); }
    to   { opacity: 1; transform: translateY(0); }
}

@keyframes fadeIn {
    from { opacity: 0; }
    to   { opacity: 1; }
}

@keyframes modalPop {
    from { opacity: 0; transform: scale(0.9) translateY(20px); }
    to   { opacity: 1; transform: scale(1)   translateY(0);    }
}

@media (max-width: 768px) {
    .tasks-page    { padding: 20px 16px 40px; }
    .task-stats    { grid-template-columns: repeat(2,1fr); gap: 10px; }
    .task-toolbar  { flex-direction: column; align-items: stretch; }
    .filter-tabs   { justify-content: center; overflow-x: auto; }
    .tasks-table   { display: block; overflow-x: auto; }
    .form-row      { flex-direction: column; }
    .page-header   { flex-direction: column; }
    .btn-add-task  { align-self: flex-start; }
    .page-title    { font-size: 28px; }
}

@media (max-width: 480px) {
    .task-stats    { grid-template-columns: repeat(2,1fr); gap: 8px; }
    .stat-val      { font-size: 30px; }
    .filter-tab    { padding: 7px 12px; font-size: 12px; }
}
</style>

<script>
function openModal() {
    document.getElementById('modalTitle').textContent    = 'Add New Task';
    document.getElementById('modalHeaderIcon').className = 'fas fa-plus';
    document.getElementById('formAction').value          = 'add';
    document.getElementById('formTaskId').value          = '';
    document.getElementById('submitIcon').className      = 'fas fa-plus';
    document.getElementById('submitLabel').textContent   = 'Add Task';
    document.getElementById('taskForm').reset();
    document.getElementById('taskModal').classList.add('open');
    document.body.style.overflow = 'hidden';
    setTimeout(() => document.getElementById('taskTitle').focus(), 100);
}

function openEditModal(id, title, desc, subject, priority, status, due) {
    document.getElementById('modalTitle').textContent    = 'Edit Task';
    document.getElementById('modalHeaderIcon').className = 'fas fa-pen';
    document.getElementById('formAction').value          = 'update';
    document.getElementById('formTaskId').value          = id;
    document.getElementById('submitIcon').className      = 'fas fa-floppy-disk';
    document.getElementById('submitLabel').textContent   = 'Save Changes';
    document.getElementById('taskTitle').value    = title;
    document.getElementById('taskDesc').value     = desc;
    document.getElementById('taskSubject').value  = subject;
    document.getElementById('taskPriority').value = priority;
    document.getElementById('taskStatus').value   = status;
    document.getElementById('taskDue').value      = due;
    document.getElementById('taskModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('taskModal').classList.remove('open');
    document.body.style.overflow = '';
}

function confirmDelete(id, name) {
    document.getElementById('deleteTaskId').value         = id;
    document.getElementById('deleteTaskName').textContent = name;
    document.getElementById('deleteModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('open');
    document.body.style.overflow = '';
}

let activeFilter = 'all';

function setFilter(filter, btn) {
    activeFilter = filter;
    document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    filterTasks();
}

function filterTasks() {
    const query   = document.getElementById('searchInput').value.toLowerCase();
    const rows    = document.querySelectorAll('.task-row');
    let   visible = 0;

    rows.forEach(row => {
        const name        = row.dataset.name   || '';
        const status      = row.dataset.status || '';
        const matchFilter = activeFilter === 'all' || status === activeFilter;
        const matchSearch = name.includes(query);
        const show        = matchFilter && matchSearch;
        row.style.display = show ? '' : 'none';
        if (show) visible++;
    });

    const noResults = document.getElementById('noResults');
    if (noResults) noResults.style.display = visible === 0 ? 'flex' : 'none';
}

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeModal(); closeDeleteModal(); }
});

document.getElementById('taskModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) closeDeleteModal();
});

setTimeout(() => {
    document.querySelectorAll('.alert').forEach(a => {
        a.style.transition = 'opacity 0.4s ease';
        a.style.opacity = '0';
        setTimeout(() => a.remove(), 400);
    });
}, 4000);
</script>

</body>
</html>