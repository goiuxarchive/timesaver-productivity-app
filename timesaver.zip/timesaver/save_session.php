<?php
session_start();
require_once 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

$data         = json_decode(file_get_contents('php://input'), true);
$user_id      = $_SESSION['user_id'];
$session_type = $data['session_type'] ?? 'pomodoro';
$duration     = (int)($data['duration']     ?? 25);
$task_id      = !empty($data['task_id']) ? (int)$data['task_id'] : null;

$allowed_types = ['pomodoro', 'short_break', 'long_break'];
if (!in_array($session_type, $allowed_types)) {
    echo json_encode(['success' => false, 'message' => 'Invalid session type']);
    exit;
}

if ($duration < 1 || $duration > 300) {
    echo json_encode(['success' => false, 'message' => 'Invalid duration']);
    exit;
}

$stmt = $pdo->prepare("
    INSERT INTO sessions (user_id, task_id, session_type, duration, started_at)
    VALUES (:uid, :tid, :type, :dur, NOW())
");

$stmt->execute([
    ':uid'  => $user_id,
    ':tid'  => $task_id,
    ':type' => $session_type,
    ':dur'  => $duration,
]);

$count = $pdo->prepare("
    SELECT COUNT(*) AS total
    FROM sessions
    WHERE user_id = :uid
      AND session_type = 'pomodoro'
      AND DATE(started_at) = CURDATE()
");
$count->execute([':uid' => $user_id]);
$today = $count->fetch()['total'];

echo json_encode([
    'success'       => true,
    'message'       => 'Session saved!',
    'sessions_today' => (int)$today,
]);