<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'config/db.php';
require_once 'csrf_helper.php';

// ── CSRF check
if (!csrf_verify()) {
    header('Location: tasks.php?error=invalid_request');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['action'])) {
    header('Location: tasks.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$action  = $_POST['action'];

// ── ADD
if ($action === 'add') {
    $title       = trim($_POST['title']       ?? '');
    $description = trim($_POST['description'] ?? '');
    $subject     = trim($_POST['subject']     ?? '');
    $priority    = $_POST['priority'] ?? 'medium';
    $status      = $_POST['status']   ?? 'pending';
    $due_date    = !empty($_POST['due_date']) ? $_POST['due_date'] : null;

    if (empty($title)) {
        header('Location: tasks.php?error=empty_title');
        exit;
    }

    $allowed_priorities = ['low', 'medium', 'high'];
    $allowed_statuses   = ['pending', 'in_progress', 'done'];

    if (!in_array($priority, $allowed_priorities)) $priority = 'medium';
    if (!in_array($status, $allowed_statuses))     $status   = 'pending';

    $stmt = $pdo->prepare("
        INSERT INTO tasks (user_id, title, description, subject, priority, status, due_date, created_at)
        VALUES (:uid, :title, :desc, :subject, :priority, :status, :due, NOW())
    ");
    $stmt->execute([
        ':uid'      => $user_id,
        ':title'    => $title,
        ':desc'     => $description,
        ':subject'  => $subject,
        ':priority' => $priority,
        ':status'   => $status,
        ':due'      => $due_date,
    ]);

    header('Location: tasks.php?success=added');
    exit;
}

// ── UPDATE
if ($action === 'update') {
    $task_id     = (int)($_POST['task_id'] ?? 0);
    $title       = trim($_POST['title']       ?? '');
    $description = trim($_POST['description'] ?? '');
    $subject     = trim($_POST['subject']     ?? '');
    $priority    = $_POST['priority'] ?? 'medium';
    $status      = $_POST['status']   ?? 'pending';
    $due_date    = !empty($_POST['due_date']) ? $_POST['due_date'] : null;

    if ($task_id <= 0 || empty($title)) {
        header('Location: tasks.php?error=invalid');
        exit;
    }

    // Verify ownership
    $check = $pdo->prepare("SELECT id FROM tasks WHERE id = :id AND user_id = :uid");
    $check->execute([':id' => $task_id, ':uid' => $user_id]);
    if (!$check->fetch()) {
        header('Location: tasks.php?error=not_found');
        exit;
    }

    $allowed_priorities = ['low', 'medium', 'high'];
    $allowed_statuses   = ['pending', 'in_progress', 'done'];

    if (!in_array($priority, $allowed_priorities)) $priority = 'medium';
    if (!in_array($status, $allowed_statuses))     $status   = 'pending';

    $stmt = $pdo->prepare("
        UPDATE tasks
        SET title=:title, description=:desc, subject=:subject,
            priority=:priority, status=:status, due_date=:due
        WHERE id=:id AND user_id=:uid
    ");
    $stmt->execute([
        ':title'    => $title,
        ':desc'     => $description,
        ':subject'  => $subject,
        ':priority' => $priority,
        ':status'   => $status,
        ':due'      => $due_date,
        ':id'       => $task_id,
        ':uid'      => $user_id,
    ]);

    header('Location: tasks.php?success=updated');
    exit;
}

// ── DELETE
if ($action === 'delete') {
    $task_id = (int)($_POST['task_id'] ?? 0);

    if ($task_id <= 0) {
        header('Location: tasks.php?error=invalid');
        exit;
    }

    // Verify ownership before deleting
    $check = $pdo->prepare("SELECT id FROM tasks WHERE id = :id AND user_id = :uid");
    $check->execute([':id' => $task_id, ':uid' => $user_id]);
    if (!$check->fetch()) {
        header('Location: tasks.php?error=not_found');
        exit;
    }

    // Nullify sessions that referenced this task
    $pdo->prepare("UPDATE sessions SET task_id = NULL WHERE task_id = :id AND user_id = :uid")
        ->execute([':id' => $task_id, ':uid' => $user_id]);

    $pdo->prepare("DELETE FROM tasks WHERE id = :id AND user_id = :uid")
        ->execute([':id' => $task_id, ':uid' => $user_id]);

    header('Location: tasks.php?success=deleted');
    exit;
}

// Fallback
header('Location: tasks.php');
exit;