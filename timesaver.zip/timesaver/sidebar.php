<?php
$current_page = basename($_SERVER['PHP_SELF']);

// ── Live sidebar stats (safe defaults)
$_sb_pending  = 0;
$_sb_sessions = 0;
$_sb_streak   = 0;

if (isset($_SESSION['user_id']) && isset($pdo)) {
    $uid = $_SESSION['user_id'];

    // Pending + in_progress tasks count
    $s1 = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE user_id = :uid AND status != 'done'");
    $s1->execute([':uid' => $uid]);
    $_sb_pending = (int)$s1->fetchColumn();

    // Pomodoro sessions completed today
    $s2 = $pdo->prepare("SELECT COUNT(*) FROM sessions WHERE user_id = :uid AND session_type = 'pomodoro' AND DATE(started_at) = CURDATE()");
    $s2->execute([':uid' => $uid]);
    $_sb_sessions = (int)$s2->fetchColumn();

    // Current day streak
    $s3 = $pdo->prepare("SELECT DISTINCT DATE(started_at) AS day FROM sessions WHERE user_id = :uid ORDER BY day DESC");
    $s3->execute([':uid' => $uid]);
    $days = $s3->fetchAll(PDO::FETCH_COLUMN);
    $check = new DateTime();
    foreach ($days as $d) {
        if ($d === $check->format('Y-m-d')) { $_sb_streak++; $check->modify('-1 day'); }
        else break;
    }
}
?>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<aside class="sidebar" id="sidebar">

    <div class="sidebar-brand">
        <div class="sidebar-logo-wrap">
            <img src="assets/images/logo.png" alt="TimeSaver Logo">
        </div>
        <span class="sidebar-brand-name">TimeSaver</span>
        <button class="sidebar-close" onclick="closeSidebar()" title="Close menu">
            <i class="fas fa-xmark"></i>
        </button>
    </div>

    <div class="sidebar-user">
        <div class="user-avatar">
            <i class="fas fa-user"></i>
        </div>
        <div class="user-info">
            <p class="user-name">
                <?php echo isset($_SESSION['first_name']) ? htmlspecialchars($_SESSION['first_name'] . ' ' . $_SESSION['last_name']) : 'Student'; ?>
            </p>
            <span class="user-badge"><i class="fas fa-circle"></i> Active</span>
        </div>
    </div>

    <div class="sidebar-stats">
        <div class="sb-stat">
            <span class="sb-stat-val"><?php echo $_sb_pending; ?></span>
            <span class="sb-stat-label">Pending</span>
        </div>
        <div class="sb-stat-sep"></div>
        <div class="sb-stat">
            <span class="sb-stat-val"><?php echo $_sb_sessions; ?></span>
            <span class="sb-stat-label">Today</span>
        </div>
        <div class="sb-stat-sep"></div>
        <div class="sb-stat">
            <span class="sb-stat-val"><?php echo $_sb_streak; ?></span>
            <span class="sb-stat-label">Streak</span>
        </div>
    </div>

    <div class="sidebar-divider"></div>

    <nav class="sidebar-nav">
        <p class="nav-section-label">Main Menu</p>

        <a href="timer.php" class="nav-item <?php echo ($current_page === 'timer.php') ? 'active' : ''; ?>">
            <div class="nav-icon"><i class="fas fa-stopwatch"></i></div>
            <span class="nav-label">Timer</span>
            <?php if ($current_page === 'timer.php'): ?>
                <div class="nav-active-dot"></div>
            <?php endif; ?>
        </a>

        <a href="tasks.php" class="nav-item <?php echo ($current_page === 'tasks.php') ? 'active' : ''; ?>">
            <div class="nav-icon"><i class="fas fa-list-check"></i></div>
            <span class="nav-label">Tasks</span>
            <?php if ($current_page === 'tasks.php'): ?>
                <div class="nav-active-dot"></div>
            <?php endif; ?>
            <?php if ($_sb_pending > 0): ?>
            <span class="nav-badge"><?php echo $_sb_pending; ?></span>
            <?php endif; ?>
        </a>

        <a href="progress.php" class="nav-item <?php echo ($current_page === 'progress.php') ? 'active' : ''; ?>">
            <div class="nav-icon"><i class="fas fa-chart-bar"></i></div>
            <span class="nav-label">Progress</span>
            <?php if ($current_page === 'progress.php'): ?>
                <div class="nav-active-dot"></div>
            <?php endif; ?>
        </a>

        <div class="sidebar-divider" style="margin: 8px 0;"></div>
        <p class="nav-section-label">Account</p>

        <a href="settings.php" class="nav-item <?php echo ($current_page === 'settings.php') ? 'active' : ''; ?>">
            <div class="nav-icon"><i class="fas fa-gear"></i></div>
            <span class="nav-label">Settings</span>
            <?php if ($current_page === 'settings.php'): ?>
                <div class="nav-active-dot"></div>
            <?php endif; ?>
        </a>

        <a href="logout.php" class="nav-item nav-item--logout">
            <div class="nav-icon"><i class="fas fa-right-from-bracket"></i></div>
            <span class="nav-label">Logout</span>
        </a>
    </nav>

    <div class="sidebar-footer">
        <p>TimeSaver &copy; <?php echo date('Y'); ?></p>
        <p>Study smarter, not harder.</p>
    </div>

</aside>

<div class="topbar" id="topbar">
    <button class="topbar-hamburger" onclick="openSidebar()" title="Open menu">
        <i class="fas fa-bars"></i>
    </button>
    <span class="topbar-title">
        <?php
            $titles = [
                'timer.php'    => '<i class="fas fa-stopwatch"></i> Timer',
                'tasks.php'    => '<i class="fas fa-list-check"></i> Tasks',
                'progress.php' => '<i class="fas fa-chart-bar"></i> Progress',
                'settings.php' => '<i class="fas fa-gear"></i> Settings',
            ];
            echo $titles[$current_page] ?? 'TimeSaver';
        ?>
    </span>
    <div class="topbar-actions">
        <a href="timer.php" class="topbar-action-btn <?php echo ($current_page === 'timer.php') ? 'active' : ''; ?>" title="Timer">
            <i class="fas fa-stopwatch"></i>
        </a>
    </div>
</div>

<style>
    :root {
        --sidebar-width: 240px;
        --sidebar-bg: #1a1a1a;
        --sidebar-red: #800517;
        --sidebar-red-hover: #a93226;
        --sidebar-text: #ffffff;
        --sidebar-muted: rgba(255,255,255,0.45);
        --sidebar-item-hover: rgba(255,255,255,0.07);
        --sidebar-active-bg: rgba(192,57,43,0.18);
        --topbar-height: 60px;
        --transition: 0.2s ease;
    }

    body.inner-page {
        margin: 0;
        padding: 0;
        background: #f0f2f5;
        font-family: 'Inter', sans-serif;
        display: flex;
        min-height: 100vh;
    }

    .sidebar {
        width: var(--sidebar-width);
        min-height: 100vh;
        background: var(--sidebar-bg);
        display: flex;
        flex-direction: column;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 200;
        transition: transform var(--transition);
        box-shadow: 4px 0 24px rgba(0,0,0,0.15);
    }

    .sidebar-brand {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 22px 20px 18px;
        position: relative;
    }

    .sidebar-logo-wrap img {
        width: 32px;
        height: 32px;
        object-fit: contain;
        filter: brightness(0) invert(1);
        flex-shrink: 0;
    }

    .sidebar-brand-name {
        font-size: 18px;
        font-weight: 900;
        color: #ffffff;
        letter-spacing: -0.5px;
        flex: 1;
    }

    .sidebar-close {
        display: none;
        background: none;
        border: none;
        color: var(--sidebar-muted);
        font-size: 16px;
        cursor: pointer;
        padding: 4px;
        transition: color var(--transition);
    }

    .sidebar-close:hover { color: #fff; }

    .sidebar-user {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px 20px;
        background: rgba(255,255,255,0.05);
        margin: 0 12px;
        border-radius: 12px;
    }

    .user-avatar {
        width: 38px;
        height: 38px;
        background: var(--sidebar-red);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .user-avatar i {
        font-size: 15px;
        color: #fff;
    }

    .sidebar-stats {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: rgba(255,255,255,0.06);
        border-radius: 12px;
        padding: 10px 14px;
        margin: 0 16px 4px;
    }

    .sb-stat {
        display: flex;
        flex-direction: column;
        align-items: center;
        flex: 1;
    }

    .sb-stat-val {
        font-size: 15px;
        font-weight: 800;
        color: #ffffff;
        line-height: 1;
        margin-bottom: 3px;
    }

    .sb-stat-label {
        font-size: 10px;
        color: rgba(255,255,255,0.45);
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .sb-stat-sep {
        width: 1px;
        height: 28px;
        background: rgba(255,255,255,0.12);
    }

    .user-info {
        display: flex;
        flex-direction: column;
        gap: 3px;
        overflow: hidden;
    }

    .user-name {
        font-size: 13px;
        font-weight: 700;
        color: #fff;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        line-height: 1;
    }

    .user-badge {
        font-size: 11px;
        color: #2ecc71;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .user-badge i {
        font-size: 7px;
    }

    .sidebar-divider {
        height: 1px;
        background: rgba(255,255,255,0.08);
        margin: 14px 20px;
    }

    .sidebar-nav {
        flex: 1;
        padding: 0 12px;
        display: flex;
        flex-direction: column;
        gap: 3px;
        overflow-y: auto;
    }

    .nav-section-label {
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 1.2px;
        text-transform: uppercase;
        color: var(--sidebar-muted);
        padding: 6px 10px 4px;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 11px 12px;
        border-radius: 10px;
        text-decoration: none;
        color: rgba(255,255,255,0.7);
        font-size: 14px;
        font-weight: 500;
        transition: background var(--transition), color var(--transition);
        position: relative;
        cursor: pointer;
    }

    .nav-item:hover {
        background: var(--sidebar-item-hover);
        color: #ffffff;
    }

    .nav-item.active {
        background: var(--sidebar-active-bg);
        color: #ffffff;
    }

    .nav-item.active .nav-icon {
        color: var(--sidebar-red);
    }

    .nav-icon {
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: rgba(255,255,255,0.06);
        font-size: 14px;
        flex-shrink: 0;
        transition: background var(--transition), color var(--transition);
    }

    .nav-item:hover .nav-icon {
        background: rgba(255,255,255,0.1);
    }

    .nav-item.active .nav-icon {
        background: rgba(192, 57, 43, 0.25);
    }

    .nav-label {
        flex: 1;
    }

    .nav-active-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--sidebar-red);
        flex-shrink: 0;
    }

    .nav-badge {
        background: var(--sidebar-red);
        color: #fff;
        font-size: 10px;
        font-weight: 700;
        padding: 2px 7px;
        border-radius: 99px;
        flex-shrink: 0;
    }

    .nav-item--logout {
        color: rgba(255,255,255,0.45);
        margin-top: 4px;
    }

    .nav-item--logout:hover {
        background: rgba(192, 57, 43, 0.15);
        color: #e74c3c;
    }

    .nav-item--logout:hover .nav-icon {
        background: rgba(192, 57, 43, 0.2);
        color: #e74c3c;
    }

    .sidebar-footer {
        padding: 16px 20px;
        border-top: 1px solid rgba(255,255,255,0.06);
    }

    .sidebar-footer p {
        font-size: 11px;
        color: var(--sidebar-muted);
        line-height: 1.6;
    }

    .main-content {
        margin-left: var(--sidebar-width);
        flex: 1;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        padding-top: 0;
    }

    .topbar {
        display: none;
        align-items: center;
        gap: 14px;
        padding: 0 20px;
        height: var(--topbar-height);
        background: #1a1a1a;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 100;
        box-shadow: 0 2px 12px rgba(0,0,0,0.2);
    }

    .topbar-hamburger {
        background: none;
        border: none;
        color: #fff;
        font-size: 18px;
        cursor: pointer;
        padding: 6px;
        border-radius: 8px;
        transition: background var(--transition);
    }

    .topbar-hamburger:hover {
        background: rgba(255,255,255,0.1);
    }

    .topbar-title {
        flex: 1;
        font-size: 16px;
        font-weight: 700;
        color: #fff;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .topbar-title i {
        color: var(--sidebar-red);
    }

    .topbar-actions {
        display: flex;
        gap: 8px;
    }

    .topbar-action-btn {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        color: rgba(255,255,255,0.6);
        font-size: 14px;
        transition: background var(--transition), color var(--transition);
    }

    .topbar-action-btn:hover,
    .topbar-action-btn.active {
        background: rgba(192,57,43,0.25);
        color: var(--sidebar-red);
    }

    .sidebar-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.5);
        z-index: 199;
        backdrop-filter: blur(2px);
    }

    @media (max-width: 768px) {
        .sidebar { transform: translateX(-100%); }
        .sidebar.open { transform: translateX(0); }
        .sidebar-close { display: flex; }
        .sidebar-overlay.open { display: block; }
        .topbar { display: flex !important; }
        .main-content {
            margin-left: 0 !important;
            padding-top: var(--topbar-height) !important;
            width: 100%;
        }
        .sidebar-stats { margin: 0 12px 4px; padding: 8px 12px; }
        .sb-stat-val   { font-size: 13px; }
        .sb-stat-label { font-size: 9px; }
    }

    @media (max-width: 480px) {
        .topbar { padding: 0 12px; }
        .topbar-title { font-size: 14px; }
    }
</style>

<script>
    function openSidebar() {
        document.getElementById('sidebar').classList.add('open');
        document.getElementById('sidebarOverlay').classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function closeSidebar() {
        document.getElementById('sidebar').classList.remove('open');
        document.getElementById('sidebarOverlay').classList.remove('open');
        document.body.style.overflow = '';
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeSidebar();
    });
</script>